// Função Edge para gerenciar documentos
// Esta função será implantada no Supabase Edge Functions

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Lidar com requisições OPTIONS para CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Criar cliente Supabase usando variáveis de ambiente
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    // Obter a sessão do usuário para verificar autenticação
    const {
      data: { session },
    } = await supabaseClient.auth.getSession()

    if (!session) {
      return new Response(
        JSON.stringify({ error: 'Não autorizado' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 401,
        }
      )
    }

    // Extrair o caminho da URL para determinar a operação
    const url = new URL(req.url)
    const path = url.pathname.split('/').filter(Boolean)
    const operation = path[path.length - 1]

    // Processar a requisição com base no método HTTP e operação
    if (req.method === 'GET') {
      if (operation === 'documentos') {
        // Listar todos os documentos
        const { data, error } = await supabaseClient
          .from('documentos')
          .select(`
            *,
            processo:processos(id, numero, tipo, cliente_id)
          `)
          .order('criado_em', { ascending: false })

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'documento' && path[path.length - 2]) {
        // Obter um documento específico pelo ID
        const id = path[path.length - 2]
        const { data, error } = await supabaseClient
          .from('documentos')
          .select(`
            *,
            processo:processos(id, numero, tipo, cliente_id, cliente:clientes(id, nome))
          `)
          .eq('id', id)
          .single()

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'processo' && path[path.length - 2]) {
        // Listar documentos de um processo específico
        const processoId = path[path.length - 2]
        const { data, error } = await supabaseClient
          .from('documentos')
          .select('*')
          .eq('processo_id', processoId)
          .order('criado_em', { ascending: false })

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
    } else if (req.method === 'POST' && operation === 'documentos') {
      // Criar um novo documento
      const { 
        processo_id, 
        nome, 
        tipo, 
        caminho_arquivo, 
        status 
      } = await req.json()

      const { data, error } = await supabaseClient
        .from('documentos')
        .insert([
          {
            processo_id,
            nome,
            tipo,
            caminho_arquivo,
            status
          }
        ])
        .select()

      if (error) throw error

      return new Response(
        JSON.stringify({ data: data[0] }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 201,
        }
      )
    } else if (req.method === 'PUT' && operation === 'documento' && path[path.length - 2]) {
      // Atualizar um documento existente
      const id = path[path.length - 2]
      const updates = await req.json()

      const { data, error } = await supabaseClient
        .from('documentos')
        .update(updates)
        .eq('id', id)
        .select()

      if (error) throw error

      return new Response(
        JSON.stringify({ data: data[0] }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    } else if (req.method === 'DELETE' && operation === 'documento' && path[path.length - 2]) {
      // Excluir um documento
      const id = path[path.length - 2]

      const { error } = await supabaseClient
        .from('documentos')
        .delete()
        .eq('id', id)

      if (error) throw error

      return new Response(
        JSON.stringify({ success: true }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    // Se chegou aqui, a rota não foi encontrada
    return new Response(
      JSON.stringify({ error: 'Rota não encontrada' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 404,
      }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})
