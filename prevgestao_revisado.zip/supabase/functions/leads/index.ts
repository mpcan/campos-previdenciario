// Função Edge para gerenciar leads
// Esta função será implantada no Supabase Edge Functions

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Lidar com requisições OPTIONS para CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Criar cliente Supabase usando variáveis de ambiente
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    // Obter a sessão do usuário para verificar autenticação
    const {
      data: { session },
    } = await supabaseClient.auth.getSession()

    if (!session) {
      return new Response(
        JSON.stringify({ error: 'Não autorizado' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 401,
        }
      )
    }

    // Extrair o caminho da URL para determinar a operação
    const url = new URL(req.url)
    const path = url.pathname.split('/').filter(Boolean)
    const operation = path[path.length - 1]

    // Processar a requisição com base no método HTTP e operação
    if (req.method === 'GET') {
      if (operation === 'leads') {
        // Listar todos os leads
        const { data, error } = await supabaseClient
          .from('leads')
          .select(`
            *,
            responsavel:usuarios(id, nome)
          `)
          .order('data_cadastro', { ascending: false })

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'lead' && path[path.length - 2]) {
        // Obter um lead específico pelo ID
        const id = path[path.length - 2]
        const { data, error } = await supabaseClient
          .from('leads')
          .select(`
            *,
            responsavel:usuarios(id, nome, email),
            interacoes:interacoes_lead(*)
          `)
          .eq('id', id)
          .single()

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
    } else if (req.method === 'POST') {
      if (operation === 'leads') {
        // Criar um novo lead
        const { 
          nome, 
          telefone, 
          email, 
          origem, 
          status, 
          interesse, 
          observacoes, 
          responsavel_id 
        } = await req.json()

        const { data, error } = await supabaseClient
          .from('leads')
          .insert([
            {
              nome,
              telefone,
              email,
              origem,
              status: status || 'Novo',
              interesse,
              observacoes,
              responsavel_id
            }
          ])
          .select()

        if (error) throw error

        // Se a criação for bem-sucedida, enviar mensagem de boas-vindas via WhatsApp
        if (data && data.length > 0) {
          try {
            // Obter configuração do WhatsApp
            const { data: configData, error: configError } = await supabaseClient
              .from('configuracoes_whatsapp')
              .select('*')
              .eq('ativo', true)
              .single()

            if (!configError && configData) {
              // Obter modelo de mensagem de boas-vindas
              const { data: modeloData, error: modeloError } = await supabaseClient
                .from('modelos_mensagem')
                .select('*')
                .eq('nome', 'Boas-vindas')
                .single()

              if (!modeloError && modeloData) {
                // Substituir variáveis no modelo
                let mensagem = modeloData.conteudo
                mensagem = mensagem.replace('{{nome}}', nome)

                // Registrar mensagem de saída
                await supabaseClient
                  .from('mensagens_whatsapp')
                  .insert([
                    {
                      lead_id: data[0].id,
                      direcao: 'Saída',
                      conteudo: mensagem,
                      tipo: 'Texto',
                      status: 'Pendente'
                    }
                  ])
              }
            }
          } catch (whatsappError) {
            console.error('Erro ao enviar mensagem de boas-vindas:', whatsappError)
          }
        }

        return new Response(
          JSON.stringify({ data: data[0] }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 201,
          }
        )
      } else if (operation === 'importar') {
        // Processar importação de leads
        const { leads, formato, nome_arquivo, usuario_id } = await req.json()

        // Criar registro de importação
        const { data: importacao, error: importacaoError } = await supabaseClient
          .from('importacoes_lead')
          .insert([
            {
              usuario_id,
              nome_arquivo,
              formato,
              total_registros: leads.length,
              status: 'Em processamento'
            }
          ])
          .select()

        if (importacaoError) throw importacaoError

        // Processar cada lead da importação
        let importados = 0
        let erros = 0
        let logErros = []

        for (const lead of leads) {
          try {
            const { error: leadError } = await supabaseClient
              .from('leads')
              .insert([
                {
                  nome: lead.nome,
                  telefone: lead.telefone,
                  email: lead.email || null,
                  origem: 'Importação',
                  status: 'Novo',
                  interesse: lead.interesse || null,
                  observacoes: lead.observacoes || null,
                  responsavel_id: lead.responsavel_id || usuario_id
                }
              ])

            if (leadError) {
              erros++
              logErros.push(`Erro ao importar lead ${lead.nome}: ${leadError.message}`)
            } else {
              importados++
            }
          } catch (e) {
            erros++
            logErros.push(`Erro ao processar lead ${lead.nome}: ${e.message}`)
          }
        }

        // Atualizar registro de importação
        await supabaseClient
          .from('importacoes_lead')
          .update({
            registros_importados: importados,
            registros_com_erro: erros,
            log_erros: logErros.join('\n'),
            status: 'Concluído',
            data_fim: new Date().toISOString()
          })
          .eq('id', importacao[0].id)

        return new Response(
          JSON.stringify({ 
            success: true, 
            importados, 
            erros,
            importacao_id: importacao[0].id
          }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
    } else if (req.method === 'PUT' && operation === 'lead' && path[path.length - 2]) {
      // Atualizar um lead existente
      const id = path[path.length - 2]
      const updates = await req.json()

      const { data, error } = await supabaseClient
        .from('leads')
        .update(updates)
        .eq('id', id)
        .select()

      if (error) throw error

      return new Response(
        JSON.stringify({ data: data[0] }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    } else if (req.method === 'DELETE' && operation === 'lead' && path[path.length - 2]) {
      // Desativar um lead (soft delete)
      const id = path[path.length - 2]

      const { data, error } = await supabaseClient
        .from('leads')
        .update({ ativo: false })
        .eq('id', id)
        .select()

      if (error) throw error

      return new Response(
        JSON.stringify({ data: data[0] }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }

    // Se chegou aqui, a rota não foi encontrada
    return new Response(
      JSON.stringify({ error: 'Rota não encontrada' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 404,
      }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})
