// Função Edge para gerenciar campanhas de WhatsApp
// Esta função será implantada no Supabase Edge Functions

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Lidar com requisições OPTIONS para CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Criar cliente Supabase usando variáveis de ambiente
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    // Obter a sessão do usuário para verificar autenticação
    const {
      data: { session },
    } = await supabaseClient.auth.getSession()

    if (!session) {
      return new Response(
        JSON.stringify({ error: 'Não autorizado' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 401,
        }
      )
    }

    // Extrair o caminho da URL para determinar a operação
    const url = new URL(req.url)
    const path = url.pathname.split('/').filter(Boolean)
    const operation = path[path.length - 1]

    // Processar a requisição com base no método HTTP e operação
    if (req.method === 'GET') {
      if (operation === 'campanhas') {
        // Listar todas as campanhas
        const { data, error } = await supabaseClient
          .from('campanhas_whatsapp')
          .select(`
            *,
            responsavel:usuarios(id, nome)
          `)
          .order('data_criacao', { ascending: false })

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'campanha' && path[path.length - 2]) {
        // Obter uma campanha específica pelo ID
        const id = path[path.length - 2]
        const { data, error } = await supabaseClient
          .from('campanhas_whatsapp')
          .select(`
            *,
            responsavel:usuarios(id, nome, email),
            destinatarios:destinatarios_campanha(
              id,
              status,
              data_envio,
              erro,
              lead:leads(id, nome, telefone, email)
            )
          `)
          .eq('id', id)
          .single()

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'modelos') {
        // Listar todos os modelos de mensagem
        const { data, error } = await supabaseClient
          .from('modelos_mensagem')
          .select('*')
          .eq('ativo', true)
          .order('nome')

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
    } else if (req.method === 'POST') {
      if (operation === 'campanhas') {
        // Criar uma nova campanha
        const { 
          nome, 
          descricao, 
          mensagem, 
          responsavel_id 
        } = await req.json()

        const { data, error } = await supabaseClient
          .from('campanhas_whatsapp')
          .insert([
            {
              nome,
              descricao,
              mensagem,
              status: 'Rascunho',
              responsavel_id: responsavel_id || session.user.id
            }
          ])
          .select()

        if (error) throw error

        return new Response(
          JSON.stringify({ data: data[0] }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 201,
          }
        )
      } else if (operation === 'adicionar-destinatarios' && path[path.length - 2]) {
        // Adicionar destinatários a uma campanha
        const campanha_id = path[path.length - 2]
        const { leads_ids } = await req.json()

        const destinatarios = leads_ids.map(lead_id => ({
          campanha_id,
          lead_id,
          status: 'Pendente'
        }))

        const { data, error } = await supabaseClient
          .from('destinatarios_campanha')
          .insert(destinatarios)
          .select()

        if (error) throw error

        return new Response(
          JSON.stringify({ 
            success: true, 
            count: data.length,
            data
          }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'enviar' && path[path.length - 2]) {
        // Enviar uma campanha
        const campanha_id = path[path.length - 2]
        
        // Atualizar status da campanha
        const { data: campanha, error: campanhaError } = await supabaseClient
          .from('campanhas_whatsapp')
          .update({ 
            status: 'Em andamento',
            data_envio: new Date().toISOString()
          })
          .eq('id', campanha_id)
          .select()

        if (campanhaError) throw campanhaError

        // Obter destinatários pendentes
        const { data: destinatarios, error: destinatariosError } = await supabaseClient
          .from('destinatarios_campanha')
          .select(`
            id,
            lead:leads(id, nome, telefone)
          `)
          .eq('campanha_id', campanha_id)
          .eq('status', 'Pendente')

        if (destinatariosError) throw destinatariosError

        // Processar cada destinatário
        let enviados = 0
        let falhas = 0

        for (const destinatario of destinatarios) {
          try {
            // Substituir variáveis na mensagem
            let mensagem = campanha[0].mensagem
            mensagem = mensagem.replace('{{nome}}', destinatario.lead.nome)

            // Registrar mensagem de saída
            const { data: mensagem_data, error: mensagemError } = await supabaseClient
              .from('mensagens_whatsapp')
              .insert([
                {
                  lead_id: destinatario.lead.id,
                  campanha_id,
                  direcao: 'Saída',
                  conteudo: mensagem,
                  tipo: 'Texto',
                  status: 'Enviado'
                }
              ])
              .select()

            if (mensagemError) throw mensagemError

            // Atualizar status do destinatário
            await supabaseClient
              .from('destinatarios_campanha')
              .update({ 
                status: 'Enviado',
                data_envio: new Date().toISOString()
              })
              .eq('id', destinatario.id)

            enviados++
          } catch (e) {
            // Registrar falha
            await supabaseClient
              .from('destinatarios_campanha')
              .update({ 
                status: 'Falha',
                erro: e.message
              })
              .eq('id', destinatario.id)

            falhas++
          }
        }

        // Atualizar status da campanha se todos foram processados
        if (enviados + falhas === destinatarios.length) {
          await supabaseClient
            .from('campanhas_whatsapp')
            .update({ 
              status: falhas === 0 ? 'Concluído' : 'Concluído com falhas'
            })
            .eq('id', campanha_id)
        }

        return new Response(
          JSON.stringify({ 
            success: true, 
            enviados,
            falhas,
            total: destinatarios.length
          }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'modelos') {
        // Criar um novo modelo de mensagem
        const { 
          nome, 
          conteudo, 
          tipo, 
          categoria 
        } = await req.json()

        const { data, error } = await supabaseClient
          .from('modelos_mensagem')
          .insert([
            {
              nome,
              conteudo,
              tipo: tipo || 'Texto',
              categoria,
              ativo: true
            }
          ])
          .select()

        if (error) throw error

        return new Response(
          JSON.stringify({ data: data[0] }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 201,
          }
        )
      }
    } else if (req.method === 'PUT') {
      if (operation === 'campanha' && path[path.length - 2]) {
        // Atualizar uma campanha existente
        const id = path[path.length - 2]
        const updates = await req.json()

        const { data, error } = await supabaseClient
          .from('campanhas_whatsapp')
          .update(updates)
          .eq('id', id)
          .select()

        if (error) throw error

        return new Response(
          JSON.stringify({ data: data[0] }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'modelo' && path[path.length - 2]) {
        // Atualizar um modelo existente
        const id = path[path.length - 2]
        const updates = await req.json()

        const { data, error } = await supabaseClient
          .from('modelos_mensagem')
          .update(updates)
          .eq('id', id)
          .select()

        if (error) throw error

        return new Response(
          JSON.stringify({ data: data[0] }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
    } else if (req.method === 'DELETE') {
      if (operation === 'campanha' && path[path.length - 2]) {
        // Excluir uma campanha
        const id = path[path.length - 2]

        const { error } = await supabaseClient
          .from('campanhas_whatsapp')
          .delete()
          .eq('id', id)

        if (error) throw error

        return new Response(
          JSON.stringify({ success: true }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'modelo' && path[path.length - 2]) {
        // Desativar um modelo (soft delete)
        const id = path[path.length - 2]

        const { data, error } = await supabaseClient
          .from('modelos_mensagem')
          .update({ ativo: false })
          .eq('id', id)
          .select()

        if (error) throw error

        return new Response(
          JSON.stringify({ data: data[0] }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
    }

    // Se chegou aqui, a rota não foi encontrada
    return new Response(
      JSON.stringify({ error: 'Rota não encontrada' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 404,
      }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})
