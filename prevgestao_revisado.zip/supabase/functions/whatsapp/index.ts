// Função Edge para gerenciar mensagens de WhatsApp
// Esta função será implantada no Supabase Edge Functions

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Lidar com requisições OPTIONS para CORS
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Criar cliente Supabase usando variáveis de ambiente
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    )

    // Extrair o caminho da URL para determinar a operação
    const url = new URL(req.url)
    const path = url.pathname.split('/').filter(Boolean)
    const operation = path[path.length - 1]

    // Processar webhook do WhatsApp (não requer autenticação)
    if (operation === 'webhook' && req.method === 'POST') {
      const payload = await req.json()
      
      // Verificar se é uma mensagem recebida
      if (payload.entry && 
          payload.entry[0].changes && 
          payload.entry[0].changes[0].value.messages && 
          payload.entry[0].changes[0].value.messages.length > 0) {
        
        const message = payload.entry[0].changes[0].value.messages[0]
        const from = message.from // Número de telefone do remetente
        const messageId = message.id
        let messageContent = ''
        let messageType = 'Texto'
        
        // Extrair conteúdo da mensagem com base no tipo
        if (message.text) {
          messageContent = message.text.body
        } else if (message.image) {
          messageContent = message.image.caption || 'Imagem recebida'
          messageType = 'Imagem'
        } else if (message.audio) {
          messageContent = 'Áudio recebido'
          messageType = 'Áudio'
        } else if (message.document) {
          messageContent = message.document.caption || 'Documento recebido'
          messageType = 'Documento'
        } else if (message.video) {
          messageContent = message.video.caption || 'Vídeo recebido'
          messageType = 'Vídeo'
        }
        
        // Buscar ou criar lead com base no número de telefone
        const { data: leadData, error: leadError } = await supabaseClient
          .from('leads')
          .select('*')
          .eq('telefone', from)
          .limit(1)
        
        let leadId
        
        if (leadError || leadData.length === 0) {
          // Criar novo lead
          const { data: newLead, error: newLeadError } = await supabaseClient
            .from('leads')
            .insert([
              {
                nome: `Contato ${from}`,
                telefone: from,
                origem: 'WhatsApp',
                status: 'Novo'
              }
            ])
            .select()
            
          if (newLeadError) throw newLeadError
          leadId = newLead[0].id
        } else {
          leadId = leadData[0].id
          
          // Atualizar data da última interação
          await supabaseClient
            .from('leads')
            .update({ data_ultima_interacao: new Date().toISOString() })
            .eq('id', leadId)
        }
        
        // Registrar mensagem recebida
        const { data: mensagemData, error: mensagemError } = await supabaseClient
          .from('mensagens_whatsapp')
          .insert([
            {
              lead_id: leadId,
              direcao: 'Entrada',
              conteudo: messageContent,
              tipo: messageType,
              status: 'Recebido',
              whatsapp_message_id: messageId,
              data_entrega: new Date().toISOString(),
              data_leitura: new Date().toISOString()
            }
          ])
          .select()
          
        if (mensagemError) throw mensagemError
        
        // Verificar se deve enviar resposta automática
        const { data: configData, error: configError } = await supabaseClient
          .from('configuracoes_whatsapp')
          .select('*')
          .eq('ativo', true)
          .single()
          
        if (!configError && configData) {
          const agora = new Date()
          const hora = agora.getHours()
          const diaSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'][agora.getDay()]
          
          // Verificar se está dentro do horário de funcionamento
          const horaInicio = parseInt(configData.horario_funcionamento_inicio.split(':')[0])
          const horaFim = parseInt(configData.horario_funcionamento_fim.split(':')[0])
          const dentroHorario = hora >= horaInicio && hora < horaFim
          const diaFuncionamento = configData.dias_funcionamento.includes(diaSemana)
          
          let respostaAutomatica = null
          
          if (!dentroHorario || !diaFuncionamento) {
            // Fora do horário de funcionamento, enviar mensagem de ausência
            respostaAutomatica = configData.mensagem_ausencia
          } else if (leadData.length === 0) {
            // Novo lead, enviar mensagem de boas-vindas
            respostaAutomatica = configData.mensagem_boas_vindas
          }
          
          if (respostaAutomatica) {
            // Registrar mensagem de resposta automática
            await supabaseClient
              .from('mensagens_whatsapp')
              .insert([
                {
                  lead_id: leadId,
                  direcao: 'Saída',
                  conteudo: respostaAutomatica,
                  tipo: 'Texto',
                  status: 'Enviado',
                  data_envio: new Date().toISOString()
                }
              ])
          }
        }
        
        // Registrar interação
        await supabaseClient
          .from('interacoes_lead')
          .insert([
            {
              lead_id: leadId,
              tipo: 'Mensagem WhatsApp',
              descricao: `Mensagem recebida: ${messageContent.substring(0, 100)}${messageContent.length > 100 ? '...' : ''}`,
              data_interacao: new Date().toISOString()
            }
          ])
      }
      
      // Responder ao webhook
      return new Response(
        JSON.stringify({ success: true }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      )
    }
    
    // Para as demais operações, verificar autenticação
    const {
      data: { session },
    } = await supabaseClient.auth.getSession()

    if (!session) {
      return new Response(
        JSON.stringify({ error: 'Não autorizado' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 401,
        }
      )
    }

    // Processar a requisição com base no método HTTP e operação
    if (req.method === 'GET') {
      if (operation === 'mensagens' && path[path.length - 2]) {
        // Obter mensagens de um lead específico
        const leadId = path[path.length - 2]
        const { data, error } = await supabaseClient
          .from('mensagens_whatsapp')
          .select('*')
          .eq('lead_id', leadId)
          .order('data_envio', { ascending: true })

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      } else if (operation === 'configuracao') {
        // Obter configuração do WhatsApp
        const { data, error } = await supabaseClient
          .from('configuracoes_whatsapp')
          .select('*')
          .eq('ativo', true)
          .single()

        if (error) throw error

        return new Response(
          JSON.stringify({ data }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
    } else if (req.method === 'POST') {
      if (operation === 'enviar') {
        // Enviar mensagem para um lead
        const { 
          lead_id, 
          conteudo, 
          tipo 
        } = await req.json()

        // Registrar mensagem
        const { data, error } = await supabaseClient
          .from('mensagens_whatsapp')
          .insert([
            {
              lead_id,
              direcao: 'Saída',
              conteudo,
              tipo: tipo || 'Texto',
              status: 'Enviado',
              data_envio: new Date().toISOString()
            }
          ])
          .select()

        if (error) throw error

        // Atualizar data da última interação do lead
        await supabaseClient
          .from('leads')
          .update({ data_ultima_interacao: new Date().toISOString() })
          .eq('id', lead_id)

        // Registrar interação
        await supabaseClient
          .from('interacoes_lead')
          .insert([
            {
              lead_id,
              usuario_id: session.user.id,
              tipo: 'Mensagem WhatsApp',
              descricao: `Mensagem enviada: ${conteudo.substring(0, 100)}${conteudo.length > 100 ? '...' : ''}`,
              data_interacao: new Date().toISOString()
            }
          ])

        return new Response(
          JSON.stringify({ data: data[0] }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 201,
          }
        )
      }
    } else if (req.method === 'PUT') {
      if (operation === 'configuracao') {
        // Atualizar configuração do WhatsApp
        const updates = await req.json()

        const { data, error } = await supabaseClient
          .from('configuracoes_whatsapp')
          .update(updates)
          .eq('ativo', true)
          .select()

        if (error) throw error

        return new Response(
          JSON.stringify({ data: data[0] }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            status: 200,
          }
        )
      }
    }

    // Se chegou aqui, a rota não foi encontrada
    return new Response(
      JSON.stringify({ error: 'Rota não encontrada' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 404,
      }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    )
  }
})
