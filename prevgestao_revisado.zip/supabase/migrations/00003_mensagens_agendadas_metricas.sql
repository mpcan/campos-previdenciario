-- Migração para adicionar tabelas de mensagens agendadas e métricas de campanhas
-- Autor: Manus AI
-- Data: 17/04/2025

-- Tabela para mensagens agendadas
CREATE TABLE IF NOT EXISTS mensagens_agendadas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
  cliente_id UUID REFERENCES clientes(id) ON DELETE CASCADE,
  conteudo TEXT NOT NULL,
  data_hora_agendada TIMESTAMP WITH TIME ZONE NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pendente',
  regra_automacao VARCHAR(50),
  data_criacao TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  criado_por UUID REFERENCES usuarios(id) ON DELETE SET NULL,
  
  -- Garantir que pelo menos um destinatário seja especificado
  CONSTRAINT check_destinatario CHECK (lead_id IS NOT NULL OR cliente_id IS NOT NULL)
);

-- Índices para otimizar consultas
CREATE INDEX IF NOT EXISTS idx_mensagens_agendadas_lead_id ON mensagens_agendadas(lead_id);
CREATE INDEX IF NOT EXISTS idx_mensagens_agendadas_cliente_id ON mensagens_agendadas(cliente_id);
CREATE INDEX IF NOT EXISTS idx_mensagens_agendadas_status ON mensagens_agendadas(status);
CREATE INDEX IF NOT EXISTS idx_mensagens_agendadas_data_hora ON mensagens_agendadas(data_hora_agendada);

-- Tabela para métricas de campanhas
CREATE TABLE IF NOT EXISTS metricas_campanhas (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  campanha_id UUID NOT NULL REFERENCES campanhas(id) ON DELETE CASCADE,
  total_enviadas INTEGER NOT NULL DEFAULT 0,
  total_entregues INTEGER NOT NULL DEFAULT 0,
  total_lidas INTEGER NOT NULL DEFAULT 0,
  total_respondidas INTEGER NOT NULL DEFAULT 0,
  taxa_conversao DECIMAL(5,2) DEFAULT 0,
  data_atualizacao TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  observacoes TEXT
);

CREATE INDEX IF NOT EXISTS idx_metricas_campanhas_campanha_id ON metricas_campanhas(campanha_id);

-- Tabela para integrações com Gov.br
CREATE TABLE IF NOT EXISTS integracao_govbr (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE,
  cliente_id UUID REFERENCES clientes(id) ON DELETE CASCADE,
  token TEXT,
  data_expiracao TIMESTAMP WITH TIME ZONE,
  status VARCHAR(20) NOT NULL DEFAULT 'ativo',
  dados_verificados JSONB,
  
  -- Garantir que pelo menos um usuário ou cliente seja especificado
  CONSTRAINT check_usuario_cliente CHECK (usuario_id IS NOT NULL OR cliente_id IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS idx_integracao_govbr_usuario_id ON integracao_govbr(usuario_id);
CREATE INDEX IF NOT EXISTS idx_integracao_govbr_cliente_id ON integracao_govbr(cliente_id);

-- Tabela para integrações com INSS Digital
CREATE TABLE IF NOT EXISTS integracao_inss (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  processo_id UUID NOT NULL REFERENCES processos(id) ON DELETE CASCADE,
  numero_beneficio VARCHAR(20),
  tipo_beneficio VARCHAR(50),
  status_beneficio VARCHAR(30),
  data_atualizacao TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW(),
  dados_adicionais JSONB
);

CREATE INDEX IF NOT EXISTS idx_integracao_inss_processo_id ON integracao_inss(processo_id);
CREATE INDEX IF NOT EXISTS idx_integracao_inss_numero_beneficio ON integracao_inss(numero_beneficio);

-- Adicionar campos para métricas na tabela de campanhas_leads
ALTER TABLE campanhas_leads ADD COLUMN IF NOT EXISTS data_leitura TIMESTAMP WITH TIME ZONE;
ALTER TABLE campanhas_leads ADD COLUMN IF NOT EXISTS data_resposta TIMESTAMP WITH TIME ZONE;
ALTER TABLE campanhas_leads ADD COLUMN IF NOT EXISTS convertido BOOLEAN DEFAULT FALSE;
ALTER TABLE campanhas_leads ADD COLUMN IF NOT EXISTS data_conversao TIMESTAMP WITH TIME ZONE;

-- Função para atualizar métricas de campanha automaticamente
CREATE OR REPLACE FUNCTION atualizar_metricas_campanha()
RETURNS TRIGGER AS $$
BEGIN
  -- Inserir ou atualizar métricas
  INSERT INTO metricas_campanhas (campanha_id, total_enviadas, total_entregues, total_lidas, total_respondidas)
  VALUES (
    NEW.campanha_id,
    (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id),
    (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id AND status = 'enviado'),
    (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id AND data_leitura IS NOT NULL),
    (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id AND data_resposta IS NOT NULL)
  )
  ON CONFLICT (campanha_id) DO UPDATE SET
    total_enviadas = (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id),
    total_entregues = (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id AND status = 'enviado'),
    total_lidas = (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id AND data_leitura IS NOT NULL),
    total_respondidas = (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id AND data_resposta IS NOT NULL),
    data_atualizacao = NOW();
    
  -- Calcular taxa de conversão
  UPDATE metricas_campanhas
  SET taxa_conversao = 
    CASE 
      WHEN total_enviadas > 0 THEN 
        (SELECT COUNT(*) FROM campanhas_leads WHERE campanha_id = NEW.campanha_id AND convertido = TRUE) * 100.0 / total_enviadas
      ELSE 0
    END
  WHERE campanha_id = NEW.campanha_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar métricas quando status de mensagem mudar
CREATE TRIGGER trigger_atualizar_metricas_campanha
AFTER INSERT OR UPDATE ON campanhas_leads
FOR EACH ROW
EXECUTE FUNCTION atualizar_metricas_campanha();

-- Políticas de segurança (RLS)
ALTER TABLE mensagens_agendadas ENABLE ROW LEVEL SECURITY;
ALTER TABLE metricas_campanhas ENABLE ROW LEVEL SECURITY;
ALTER TABLE integracao_govbr ENABLE ROW LEVEL SECURITY;
ALTER TABLE integracao_inss ENABLE ROW LEVEL SECURITY;

-- Política para mensagens agendadas
CREATE POLICY mensagens_agendadas_policy ON mensagens_agendadas
  USING (
    criado_por = auth.uid() OR
    EXISTS (
      SELECT 1 FROM usuarios
      WHERE id = auth.uid() AND (role = 'admin' OR role = 'marketing')
    )
  );

-- Política para métricas de campanhas
CREATE POLICY metricas_campanhas_policy ON metricas_campanhas
  USING (
    EXISTS (
      SELECT 1 FROM campanhas
      WHERE id = metricas_campanhas.campanha_id AND
      (
        responsavel_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM usuarios
          WHERE id = auth.uid() AND (role = 'admin' OR role = 'marketing')
        )
      )
    )
  );

-- Política para integrações Gov.br
CREATE POLICY integracao_govbr_policy ON integracao_govbr
  USING (
    usuario_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM usuarios
      WHERE id = auth.uid() AND (role = 'admin' OR role = 'advogado')
    )
  );

-- Política para integrações INSS
CREATE POLICY integracao_inss_policy ON integracao_inss
  USING (
    EXISTS (
      SELECT 1 FROM processos
      WHERE id = integracao_inss.processo_id AND
      (
        responsavel_id = auth.uid() OR
        EXISTS (
          SELECT 1 FROM usuarios
          WHERE id = auth.uid() AND (role = 'admin' OR role = 'advogado')
        )
      )
    )
  );
