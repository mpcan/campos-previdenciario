-- Script SQL para criação das tabelas do módulo de WhatsApp e Leads no Supabase

-- Extensão para geração de UUIDs (caso ainda não exista)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de leads
CREATE TABLE leads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    telefone TEXT NOT NULL,
    email TEXT,
    origem TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Novo',
    interesse TEXT,
    observacoes TEXT,
    data_cadastro TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_ultima_interacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    responsavel_id UUID REFERENCES usuarios(id),
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de leads
CREATE INDEX idx_leads_nome ON leads(nome);
CREATE INDEX idx_leads_telefone ON leads(telefone);
CREATE INDEX idx_leads_email ON leads(email);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_origem ON leads(origem);
CREATE INDEX idx_leads_responsavel_id ON leads(responsavel_id);

-- Tabela de campanhas de WhatsApp
CREATE TABLE campanhas_whatsapp (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    descricao TEXT,
    mensagem TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Rascunho',
    data_criacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_envio TIMESTAMP WITH TIME ZONE,
    responsavel_id UUID REFERENCES usuarios(id),
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de campanhas
CREATE INDEX idx_campanhas_nome ON campanhas_whatsapp(nome);
CREATE INDEX idx_campanhas_status ON campanhas_whatsapp(status);
CREATE INDEX idx_campanhas_responsavel_id ON campanhas_whatsapp(responsavel_id);

-- Tabela de destinatários de campanhas
CREATE TABLE destinatarios_campanha (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    campanha_id UUID NOT NULL REFERENCES campanhas_whatsapp(id) ON DELETE CASCADE,
    lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    status TEXT NOT NULL DEFAULT 'Pendente',
    data_envio TIMESTAMP WITH TIME ZONE,
    erro TEXT,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(campanha_id, lead_id)
);

-- Índices para a tabela de destinatários
CREATE INDEX idx_destinatarios_campanha_id ON destinatarios_campanha(campanha_id);
CREATE INDEX idx_destinatarios_lead_id ON destinatarios_campanha(lead_id);
CREATE INDEX idx_destinatarios_status ON destinatarios_campanha(status);

-- Tabela de mensagens de WhatsApp
CREATE TABLE mensagens_whatsapp (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID REFERENCES leads(id) ON DELETE SET NULL,
    campanha_id UUID REFERENCES campanhas_whatsapp(id) ON DELETE SET NULL,
    direcao TEXT NOT NULL CHECK (direcao IN ('Entrada', 'Saída')),
    conteudo TEXT NOT NULL,
    tipo TEXT NOT NULL DEFAULT 'Texto',
    status TEXT NOT NULL,
    data_envio TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_entrega TIMESTAMP WITH TIME ZONE,
    data_leitura TIMESTAMP WITH TIME ZONE,
    whatsapp_message_id TEXT,
    erro TEXT,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de mensagens
CREATE INDEX idx_mensagens_lead_id ON mensagens_whatsapp(lead_id);
CREATE INDEX idx_mensagens_campanha_id ON mensagens_whatsapp(campanha_id);
CREATE INDEX idx_mensagens_direcao ON mensagens_whatsapp(direcao);
CREATE INDEX idx_mensagens_status ON mensagens_whatsapp(status);
CREATE INDEX idx_mensagens_data_envio ON mensagens_whatsapp(data_envio);
CREATE INDEX idx_mensagens_whatsapp_message_id ON mensagens_whatsapp(whatsapp_message_id);

-- Tabela de modelos de mensagens
CREATE TABLE modelos_mensagem (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    conteudo TEXT NOT NULL,
    tipo TEXT NOT NULL DEFAULT 'Texto',
    categoria TEXT,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de modelos
CREATE INDEX idx_modelos_nome ON modelos_mensagem(nome);
CREATE INDEX idx_modelos_categoria ON modelos_mensagem(categoria);
CREATE INDEX idx_modelos_tipo ON modelos_mensagem(tipo);

-- Tabela de configurações de WhatsApp
CREATE TABLE configuracoes_whatsapp (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero_telefone TEXT NOT NULL,
    token_acesso TEXT,
    webhook_url TEXT,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    mensagem_boas_vindas TEXT,
    mensagem_ausencia TEXT,
    horario_funcionamento_inicio TIME,
    horario_funcionamento_fim TIME,
    dias_funcionamento TEXT[],
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de interações com leads
CREATE TABLE interacoes_lead (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
    usuario_id UUID REFERENCES usuarios(id),
    tipo TEXT NOT NULL,
    descricao TEXT NOT NULL,
    data_interacao TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    resultado TEXT,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de interações
CREATE INDEX idx_interacoes_lead_id ON interacoes_lead(lead_id);
CREATE INDEX idx_interacoes_usuario_id ON interacoes_lead(usuario_id);
CREATE INDEX idx_interacoes_tipo ON interacoes_lead(tipo);
CREATE INDEX idx_interacoes_data_interacao ON interacoes_lead(data_interacao);

-- Tabela de importações de leads
CREATE TABLE importacoes_lead (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id UUID NOT NULL REFERENCES usuarios(id),
    nome_arquivo TEXT NOT NULL,
    formato TEXT NOT NULL,
    total_registros INTEGER NOT NULL DEFAULT 0,
    registros_importados INTEGER NOT NULL DEFAULT 0,
    registros_com_erro INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'Em processamento',
    log_erros TEXT,
    data_inicio TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_fim TIMESTAMP WITH TIME ZONE,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de importações
CREATE INDEX idx_importacoes_usuario_id ON importacoes_lead(usuario_id);
CREATE INDEX idx_importacoes_status ON importacoes_lead(status);
CREATE INDEX idx_importacoes_data_inicio ON importacoes_lead(data_inicio);

-- Triggers para atualização automática de timestamps (se ainda não existirem)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'update_updated_at_column') THEN
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
            NEW.atualizado_em = NOW();
            RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;
    END IF;
END
$$;

-- Triggers para as novas tabelas
CREATE TRIGGER set_timestamp_leads
BEFORE UPDATE ON leads
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_campanhas_whatsapp
BEFORE UPDATE ON campanhas_whatsapp
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_destinatarios_campanha
BEFORE UPDATE ON destinatarios_campanha
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_mensagens_whatsapp
BEFORE UPDATE ON mensagens_whatsapp
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_modelos_mensagem
BEFORE UPDATE ON modelos_mensagem
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_configuracoes_whatsapp
BEFORE UPDATE ON configuracoes_whatsapp
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_interacoes_lead
BEFORE UPDATE ON interacoes_lead
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_importacoes_lead
BEFORE UPDATE ON importacoes_lead
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Políticas de segurança (RLS - Row Level Security)

-- Habilitar RLS para todas as tabelas
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE campanhas_whatsapp ENABLE ROW LEVEL SECURITY;
ALTER TABLE destinatarios_campanha ENABLE ROW LEVEL SECURITY;
ALTER TABLE mensagens_whatsapp ENABLE ROW LEVEL SECURITY;
ALTER TABLE modelos_mensagem ENABLE ROW LEVEL SECURITY;
ALTER TABLE configuracoes_whatsapp ENABLE ROW LEVEL SECURITY;
ALTER TABLE interacoes_lead ENABLE ROW LEVEL SECURITY;
ALTER TABLE importacoes_lead ENABLE ROW LEVEL SECURITY;

-- Políticas para leads
CREATE POLICY "Usuários autenticados podem ver leads" ON leads
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar leads" ON leads
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar leads" ON leads
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para campanhas
CREATE POLICY "Usuários autenticados podem ver campanhas" ON campanhas_whatsapp
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar campanhas" ON campanhas_whatsapp
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar campanhas" ON campanhas_whatsapp
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para destinatários
CREATE POLICY "Usuários autenticados podem ver destinatários" ON destinatarios_campanha
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar destinatários" ON destinatarios_campanha
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar destinatários" ON destinatarios_campanha
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para mensagens
CREATE POLICY "Usuários autenticados podem ver mensagens" ON mensagens_whatsapp
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar mensagens" ON mensagens_whatsapp
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar mensagens" ON mensagens_whatsapp
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para modelos
CREATE POLICY "Usuários autenticados podem ver modelos" ON modelos_mensagem
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar modelos" ON modelos_mensagem
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar modelos" ON modelos_mensagem
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para configurações
CREATE POLICY "Usuários autenticados podem ver configurações" ON configuracoes_whatsapp
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Administradores podem gerenciar configurações" ON configuracoes_whatsapp
    USING (
        EXISTS (
            SELECT 1 FROM usuarios
            WHERE usuarios.id = auth.uid() AND usuarios.cargo = 'Admin'
        )
    );

-- Políticas para interações
CREATE POLICY "Usuários autenticados podem ver interações" ON interacoes_lead
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar interações" ON interacoes_lead
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar interações" ON interacoes_lead
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para importações
CREATE POLICY "Usuários autenticados podem ver importações" ON importacoes_lead
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar importações" ON importacoes_lead
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários podem gerenciar suas próprias importações" ON importacoes_lead
    FOR UPDATE USING (auth.uid() = usuario_id);

-- Inserir configuração inicial do WhatsApp
INSERT INTO configuracoes_whatsapp (
    numero_telefone,
    mensagem_boas_vindas,
    mensagem_ausencia,
    horario_funcionamento_inicio,
    horario_funcionamento_fim,
    dias_funcionamento
) VALUES (
    '+555533336517',
    'Olá! Bem-vindo ao atendimento da PrevGestão. Como podemos ajudar você hoje?',
    'Obrigado pelo seu contato. Nosso horário de atendimento é de segunda a sexta, das 9h às 18h. Retornaremos seu contato em breve.',
    '09:00',
    '18:00',
    ARRAY['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta']
);

-- Inserir alguns modelos de mensagem padrão
INSERT INTO modelos_mensagem (nome, conteudo, tipo, categoria) VALUES
('Boas-vindas', 'Olá, {{nome}}! Bem-vindo ao atendimento da PrevGestão. Como podemos ajudar você hoje?', 'Texto', 'Atendimento'),
('Agradecimento', 'Obrigado pelo seu contato, {{nome}}. Estamos à disposição para qualquer dúvida.', 'Texto', 'Atendimento'),
('Informações sobre Aposentadoria', 'Olá, {{nome}}! Para informações sobre aposentadoria, precisamos analisar seu tempo de contribuição e idade. Podemos agendar uma consulta?', 'Texto', 'Informativo'),
('Confirmação de Atendimento', 'Olá, {{nome}}! Confirmamos seu atendimento para o dia {{data}} às {{hora}}. Aguardamos sua presença.', 'Texto', 'Agendamento'),
('Lembrete de Perícia', 'Olá, {{nome}}! Lembramos que sua perícia está agendada para o dia {{data}} às {{hora}} no local {{local}}. Não se esqueça de levar seus documentos.', 'Texto', 'Lembrete');
