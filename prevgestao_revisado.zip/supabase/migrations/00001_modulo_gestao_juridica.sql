-- Script SQL para criação das tabelas do módulo de gestão jurídica no Supabase

-- Extensão para geração de UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de usuários
CREATE TABLE usuarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    senha_hash TEXT NOT NULL,
    cargo TEXT NOT NULL,
    permissoes JSONB NOT NULL DEFAULT '{}',
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de usuários
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_usuarios_cargo ON usuarios(cargo);

-- Tabela de clientes
CREATE TABLE clientes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    cpf TEXT UNIQUE,
    rg TEXT,
    data_nascimento DATE,
    endereco TEXT,
    cidade TEXT,
    estado TEXT,
    cep TEXT,
    telefone TEXT,
    email TEXT,
    profissao TEXT,
    estado_civil TEXT,
    observacoes TEXT,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de clientes
CREATE INDEX idx_clientes_nome ON clientes(nome);
CREATE INDEX idx_clientes_cpf ON clientes(cpf);
CREATE INDEX idx_clientes_telefone ON clientes(telefone);
CREATE INDEX idx_clientes_email ON clientes(email);

-- Tabela de processos
CREATE TABLE processos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cliente_id UUID NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
    responsavel_id UUID NOT NULL REFERENCES usuarios(id),
    numero TEXT,
    tipo TEXT NOT NULL CHECK (tipo IN ('Administrativo', 'Judicial')),
    beneficio_tipo TEXT,
    status TEXT NOT NULL,
    data_entrada DATE NOT NULL,
    data_distribuicao DATE,
    vara TEXT,
    comarca TEXT,
    juiz TEXT,
    observacoes TEXT,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de processos
CREATE INDEX idx_processos_cliente_id ON processos(cliente_id);
CREATE INDEX idx_processos_responsavel_id ON processos(responsavel_id);
CREATE INDEX idx_processos_numero ON processos(numero);
CREATE INDEX idx_processos_tipo ON processos(tipo);
CREATE INDEX idx_processos_status ON processos(status);
CREATE INDEX idx_processos_beneficio_tipo ON processos(beneficio_tipo);

-- Tabela de atendimentos
CREATE TABLE atendimentos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cliente_id UUID NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
    processo_id UUID REFERENCES processos(id) ON DELETE SET NULL,
    responsavel_id UUID NOT NULL REFERENCES usuarios(id),
    data DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME,
    tipo TEXT NOT NULL,
    status TEXT NOT NULL,
    observacoes TEXT,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de atendimentos
CREATE INDEX idx_atendimentos_cliente_id ON atendimentos(cliente_id);
CREATE INDEX idx_atendimentos_processo_id ON atendimentos(processo_id);
CREATE INDEX idx_atendimentos_responsavel_id ON atendimentos(responsavel_id);
CREATE INDEX idx_atendimentos_data ON atendimentos(data);
CREATE INDEX idx_atendimentos_status ON atendimentos(status);

-- Tabela de perícias
CREATE TABLE pericias (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    processo_id UUID NOT NULL REFERENCES processos(id) ON DELETE CASCADE,
    cliente_id UUID NOT NULL REFERENCES clientes(id),
    data DATE NOT NULL,
    hora TIME NOT NULL,
    local TEXT,
    perito TEXT,
    status TEXT NOT NULL,
    resultado TEXT,
    observacoes TEXT,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de perícias
CREATE INDEX idx_pericias_processo_id ON pericias(processo_id);
CREATE INDEX idx_pericias_cliente_id ON pericias(cliente_id);
CREATE INDEX idx_pericias_data ON pericias(data);
CREATE INDEX idx_pericias_status ON pericias(status);

-- Tabela de documentos
CREATE TABLE documentos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    processo_id UUID NOT NULL REFERENCES processos(id) ON DELETE CASCADE,
    nome TEXT NOT NULL,
    tipo TEXT NOT NULL,
    caminho_arquivo TEXT NOT NULL,
    status TEXT NOT NULL,
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    atualizado_em TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices para a tabela de documentos
CREATE INDEX idx_documentos_processo_id ON documentos(processo_id);
CREATE INDEX idx_documentos_tipo ON documentos(tipo);
CREATE INDEX idx_documentos_status ON documentos(status);

-- Função para atualizar o timestamp de atualização
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.atualizado_em = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para atualização automática de timestamps
CREATE TRIGGER set_timestamp_usuarios
BEFORE UPDATE ON usuarios
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_clientes
BEFORE UPDATE ON clientes
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_processos
BEFORE UPDATE ON processos
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_atendimentos
BEFORE UPDATE ON atendimentos
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_pericias
BEFORE UPDATE ON pericias
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER set_timestamp_documentos
BEFORE UPDATE ON documentos
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Políticas de segurança (RLS - Row Level Security)

-- Habilitar RLS para todas as tabelas
ALTER TABLE usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE processos ENABLE ROW LEVEL SECURITY;
ALTER TABLE atendimentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE pericias ENABLE ROW LEVEL SECURITY;
ALTER TABLE documentos ENABLE ROW LEVEL SECURITY;

-- Políticas para usuários
CREATE POLICY "Usuários podem ver seus próprios dados" ON usuarios
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Administradores podem ver todos os usuários" ON usuarios
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM usuarios
            WHERE usuarios.id = auth.uid() AND usuarios.cargo = 'Admin'
        )
    );

CREATE POLICY "Administradores podem gerenciar usuários" ON usuarios
    USING (
        EXISTS (
            SELECT 1 FROM usuarios
            WHERE usuarios.id = auth.uid() AND usuarios.cargo = 'Admin'
        )
    );

-- Políticas para clientes
CREATE POLICY "Todos os usuários autenticados podem ver clientes" ON clientes
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar clientes" ON clientes
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar clientes" ON clientes
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para processos
CREATE POLICY "Todos os usuários autenticados podem ver processos" ON processos
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar processos" ON processos
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar processos" ON processos
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para atendimentos
CREATE POLICY "Todos os usuários autenticados podem ver atendimentos" ON atendimentos
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar atendimentos" ON atendimentos
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar atendimentos" ON atendimentos
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para perícias
CREATE POLICY "Todos os usuários autenticados podem ver perícias" ON pericias
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar perícias" ON pericias
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar perícias" ON pericias
    FOR UPDATE USING (auth.role() = 'authenticated');

-- Políticas para documentos
CREATE POLICY "Todos os usuários autenticados podem ver documentos" ON documentos
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem criar documentos" ON documentos
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem atualizar documentos" ON documentos
    FOR UPDATE USING (auth.role() = 'authenticated');
