import { describe, it, expect, vi, beforeEach } from 'vitest';
import { 
  obterMetricasCampanha, 
  obterMetricasTodasCampanhas, 
  atualizarStatusLeitura,
  atualizarStatusResposta,
  marcarLeadComoConvertido,
  gerarRelatorioConversaoPorCampanha
} from '../src/lib/whatsapp/metricas-campanhas';

// Mock do cliente Supabase
vi.mock('@supabase/supabase-js', () => {
  const mockSelect = vi.fn().mockReturnThis();
  const mockEq = vi.fn().mockReturnThis();
  const mockOrder = vi.fn().mockReturnThis();
  const mockSingle = vi.fn().mockReturnThis();
  const mockIn = vi.fn().mockReturnThis();
  const mockUpsert = vi.fn().mockReturnThis();
  
  return {
    createClient: () => ({
      from: () => ({
        select: mockSelect,
        update: () => ({
          eq: mockEq,
          select: mockSelect,
          single: mockSingle
        }),
        upsert: mockUpsert,
        eq: mockEq,
        order: mockOrder,
        in: mockIn,
        rpc: vi.fn().mockReturnValue({ data: [], error: null })
      })
    })
  };
});

describe('Módulo de Métricas de Campanhas', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('obterMetricasCampanha', () => {
    it('deve retornar métricas de uma campanha específica', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = {
        id: 'metrica-123',
        campanha_id: 'campanha-123',
        total_enviadas: 100,
        total_entregues: 95,
        total_lidas: 80,
        total_respondidas: 30,
        taxa_conversao: 15.5,
        data_atualizacao: '2025-04-17T02:00:00Z'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                eq: () => ({
                  single: () => ({ data: mockData, error: null })
                })
              })
            })
          })
        };
      });

      // Executar função
      const result = await obterMetricasCampanha('campanha-123');

      // Verificar resultado
      expect(result).toEqual(mockData);
    });

    it('deve calcular e criar métricas se não existirem', async () => {
      // Configurar mock para retornar erro "not found"
      vi.mock('@supabase/supabase-js', () => {
        const mockCampanha = {
          id: 'campanha-123',
          nome: 'Campanha Teste',
          status: 'enviada'
        };
        
        const mockEnvios = [
          { campanha_id: 'campanha-123', status: 'enviado', data_leitura: '2025-04-16T10:00:00Z', data_resposta: null, convertido: false },
          { campanha_id: 'campanha-123', status: 'enviado', data_leitura: '2025-04-16T11:00:00Z', data_resposta: '2025-04-16T11:05:00Z', convertido: true },
          { campanha_id: 'campanha-123', status: 'enviado', data_leitura: null, data_resposta: null, convertido: false }
        ];
        
        const mockMetricas = {
          id: 'metrica-123',
          campanha_id: 'campanha-123',
          total_enviadas: 3,
          total_entregues: 3,
          total_lidas: 2,
          total_respondidas: 1,
          taxa_conversao: 33.33,
          data_atualizacao: '2025-04-17T02:00:00Z'
        };
        
        return {
          createClient: () => ({
            from: (table) => {
              if (table === 'metricas_campanhas') {
                return {
                  select: () => ({
                    eq: () => ({
                      single: () => ({ data: null, error: { code: 'PGRST116' } })
                    })
                  }),
                  upsert: () => ({
                    select: () => ({
                      single: () => ({ data: mockMetricas, error: null })
                    })
                  })
                };
              } else if (table === 'campanhas') {
                return {
                  select: () => ({
                    eq: () => ({
                      single: () => ({ data: mockCampanha, error: null })
                    })
                  })
                };
              } else if (table === 'campanhas_leads') {
                return {
                  select: () => ({
                    eq: () => ({ data: mockEnvios, error: null })
                  })
                };
              }
              return {};
            }
          })
        };
      });

      // Executar função
      const result = await obterMetricasCampanha('campanha-123');

      // Verificar resultado
      expect(result).toHaveProperty('campanha_id', 'campanha-123');
      expect(result).toHaveProperty('total_enviadas');
      expect(result).toHaveProperty('taxa_conversao');
    });
  });

  describe('obterMetricasTodasCampanhas', () => {
    it('deve retornar métricas de todas as campanhas', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = [
        {
          id: 'metrica-123',
          campanha_id: 'campanha-123',
          total_enviadas: 100,
          total_entregues: 95,
          total_lidas: 80,
          total_respondidas: 30,
          taxa_conversao: 15.5,
          data_atualizacao: '2025-04-17T02:00:00Z',
          campanhas: {
            id: 'campanha-123',
            nome: 'Campanha 1',
            status: 'enviada'
          }
        },
        {
          id: 'metrica-456',
          campanha_id: 'campanha-456',
          total_enviadas: 200,
          total_entregues: 190,
          total_lidas: 150,
          total_respondidas: 70,
          taxa_conversao: 25.0,
          data_atualizacao: '2025-04-16T02:00:00Z',
          campanhas: {
            id: 'campanha-456',
            nome: 'Campanha 2',
            status: 'enviada'
          }
        }
      ];
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                order: () => ({ data: mockData, error: null })
              })
            })
          })
        };
      });

      // Executar função
      const result = await obterMetricasTodasCampanhas();

      // Verificar resultado
      expect(result).toEqual(mockData);
      expect(result).toHaveLength(2);
    });
  });

  describe('atualizarStatusLeitura', () => {
    it('deve atualizar o status de leitura de uma mensagem', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = {
        id: 'campanha-lead-123',
        campanha_id: 'campanha-123',
        lead_id: 'lead-123',
        status: 'enviado',
        data_leitura: '2025-04-17T02:00:00Z'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: (table) => {
              if (table === 'campanhas_leads') {
                return {
                  update: () => ({
                    eq: () => ({
                      select: () => ({
                        single: () => ({ data: mockData, error: null })
                      })
                    })
                  })
                };
              } else if (table === 'metricas_campanhas') {
                return {
                  upsert: () => ({
                    select: () => ({
                      single: () => ({ data: { id: 'metrica-123' }, error: null })
                    })
                  })
                };
              }
              return {};
            }
          })
        };
      });

      // Executar função
      const result = await atualizarStatusLeitura('campanha-lead-123');

      // Verificar resultado
      expect(result).toEqual(mockData);
      expect(result.data_leitura).toBeDefined();
    });
  });

  describe('marcarLeadComoConvertido', () => {
    it('deve marcar um lead como convertido', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = {
        id: 'campanha-lead-123',
        campanha_id: 'campanha-123',
        lead_id: 'lead-123',
        status: 'enviado',
        convertido: true,
        data_conversao: '2025-04-17T02:00:00Z'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: (table) => {
              if (table === 'campanhas_leads') {
                return {
                  update: () => ({
                    eq: () => ({
                      select: () => ({
                        single: () => ({ data: mockData, error: null })
                      })
                    })
                  })
                };
              } else if (table === 'metricas_campanhas') {
                return {
                  upsert: () => ({
                    select: () => ({
                      single: () => ({ data: { id: 'metrica-123' }, error: null })
                    })
                  })
                };
              }
              return {};
            }
          })
        };
      });

      // Executar função
      const result = await marcarLeadComoConvertido('campanha-lead-123');

      // Verificar resultado
      expect(result).toEqual(mockData);
      expect(result.convertido).toBe(true);
      expect(result.data_conversao).toBeDefined();
    });
  });

  describe('gerarRelatorioConversaoPorCampanha', () => {
    it('deve gerar relatório de conversão por campanha', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = [
        {
          id: 'metrica-123',
          campanha_id: 'campanha-123',
          total_enviadas: 100,
          total_respondidas: 30,
          taxa_conversao: 15.5,
          campanhas: {
            id: 'campanha-123',
            nome: 'Campanha 1',
            mensagem: 'Olá, temos uma oferta especial!'
          }
        },
        {
          id: 'metrica-456',
          campanha_id: 'campanha-456',
          total_enviadas: 200,
          total_respondidas: 70,
          taxa_conversao: 25.0,
          campanhas: {
            id: 'campanha-456',
            nome: 'Campanha 2',
            mensagem: 'Você sabia que pode ter direito a um benefício?'
          }
        }
      ];
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                order: () => ({
                  in: () => ({ data: mockData, error: null })
                })
              })
            })
          })
        };
      });

      // Executar função
      const result = await gerarRelatorioConversaoPorCampanha(
        new Date('2025-04-01'),
        new Date('2025-04-17')
      );

      // Verificar resultado
      expect(result).toEqual(mockData);
      expect(result).toHaveLength(2);
    });
  });
});
