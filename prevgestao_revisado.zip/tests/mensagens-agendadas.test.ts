import { describe, it, expect, vi, beforeEach } from 'vitest';
import { 
  agendarMensagemAutomatica, 
  obterMensagensAgendadas, 
  processarMensagensAgendadas 
} from '../src/lib/whatsapp/mensagens-agendadas';

// Mock do cliente Supabase
vi.mock('@supabase/supabase-js', () => {
  const mockSelect = vi.fn().mockReturnThis();
  const mockEq = vi.fn().mockReturnThis();
  const mockGte = vi.fn().mockReturnThis();
  const mockLte = vi.fn().mockReturnThis();
  const mockOrder = vi.fn().mockReturnThis();
  const mockSingle = vi.fn().mockReturnThis();
  const mockIn = vi.fn().mockReturnThis();
  
  return {
    createClient: () => ({
      from: () => ({
        insert: () => ({
          select: mockSelect,
          single: mockSingle
        }),
        select: mockSelect,
        update: () => ({
          eq: mockEq,
          select: mockSelect,
          single: mockSingle
        }),
        eq: mockEq,
        gte: mockGte,
        lte: mockLte,
        order: mockOrder,
        in: mockIn
      }),
      auth: {
        getUser: vi.fn().mockResolvedValue({ data: { user: { id: 'test-user-id' } } })
      }
    })
  };
});

describe('Módulo de Mensagens Agendadas', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('agendarMensagemAutomatica', () => {
    it('deve agendar uma mensagem para um lead', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = {
        id: 'msg-123',
        lead_id: 'lead-123',
        conteudo: 'Olá {nome}, tudo bem?',
        data_hora_agendada: '2025-04-20T10:00:00Z',
        status: 'pendente'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              insert: () => ({
                select: () => ({
                  single: () => ({ data: mockData, error: null })
                })
              })
            })
          })
        };
      });

      // Executar função
      const result = await agendarMensagemAutomatica({
        leadId: 'lead-123',
        conteudo: 'Olá {nome}, tudo bem?',
        dataHoraAgendada: new Date('2025-04-20T10:00:00Z'),
        criadoPor: 'user-123'
      });

      // Verificar resultado
      expect(result).toEqual(mockData);
    });

    it('deve lançar erro se nenhum destinatário for especificado', async () => {
      await expect(
        agendarMensagemAutomatica({
          conteudo: 'Mensagem sem destinatário',
          dataHoraAgendada: new Date(),
          criadoPor: 'user-123'
        })
      ).rejects.toThrow('É necessário especificar pelo menos um destinatário');
    });
  });

  describe('obterMensagensAgendadas', () => {
    it('deve retornar mensagens agendadas com filtros aplicados', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = [
        {
          id: 'msg-123',
          lead_id: 'lead-123',
          conteudo: 'Mensagem 1',
          data_hora_agendada: '2025-04-20T10:00:00Z',
          status: 'pendente'
        },
        {
          id: 'msg-456',
          cliente_id: 'cliente-456',
          conteudo: 'Mensagem 2',
          data_hora_agendada: '2025-04-21T14:00:00Z',
          status: 'pendente'
        }
      ];
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                order: () => ({
                  eq: () => ({
                    gte: () => ({
                      lte: () => ({ data: mockData, error: null })
                    })
                  })
                })
              })
            })
          })
        };
      });

      // Executar função com filtros
      const result = await obterMensagensAgendadas({
        status: 'pendente',
        dataInicio: new Date('2025-04-20T00:00:00Z'),
        dataFim: new Date('2025-04-22T00:00:00Z')
      });

      // Verificar resultado
      expect(result).toEqual(mockData);
    });
  });

  describe('processarMensagensAgendadas', () => {
    it('deve processar mensagens pendentes que estão prontas para envio', async () => {
      // Configurar mock para retornar mensagens pendentes
      const mockMensagens = [
        {
          id: 'msg-123',
          lead_id: 'lead-123',
          leads: {
            id: 'lead-123',
            nome: 'João',
            telefone: '5511999999999',
            email: 'joao@exemplo.com'
          },
          conteudo: 'Olá {nome}, tudo bem?',
          data_hora_agendada: '2025-04-17T02:00:00Z',
          status: 'pendente'
        },
        {
          id: 'msg-456',
          cliente_id: 'cliente-456',
          clientes: {
            id: 'cliente-456',
            nome: 'Maria',
            telefone: '5511888888888',
            email: 'maria@exemplo.com'
          },
          conteudo: 'Olá {nome}, seu processo foi atualizado.',
          data_hora_agendada: '2025-04-17T02:30:00Z',
          status: 'pendente'
        }
      ];
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: (table) => {
              if (table === 'mensagens_agendadas') {
                return {
                  select: () => ({
                    eq: () => ({
                      lte: () => ({ data: mockMensagens, error: null })
                    })
                  }),
                  update: () => ({
                    eq: () => ({ data: { status: 'enviado' }, error: null })
                  })
                };
              } else if (table === 'mensagens_whatsapp') {
                return {
                  insert: () => ({
                    select: () => ({
                      single: () => ({ data: { id: 'whatsapp-msg-123' }, error: null })
                    })
                  })
                };
              }
              return {};
            }
          })
        };
      });

      // Executar função
      const result = await processarMensagensAgendadas();

      // Verificar resultado
      expect(result.processadas).toBe(2);
    });
  });
});
