import { describe, it, expect, vi, beforeEach } from 'vitest';
import { 
  autenticarViaGovBr,
  obterPerfilGovBr,
  validarDocumentoViaGovBr,
  conectarClienteGovBr
} from '../src/lib/integracoes/govbr';

// Mock do cliente Supabase
vi.mock('@supabase/supabase-js', () => {
  const mockSelect = vi.fn().mockReturnThis();
  const mockEq = vi.fn().mockReturnThis();
  const mockSingle = vi.fn().mockReturnThis();
  const mockUpsert = vi.fn().mockReturnThis();
  const mockInsert = vi.fn().mockReturnThis();
  const mockUpdate = vi.fn().mockReturnThis();
  
  return {
    createClient: () => ({
      from: () => ({
        select: mockSelect,
        insert: mockInsert,
        update: mockUpdate,
        upsert: mockUpsert,
        eq: mockEq,
        single: mockSingle
      }),
      auth: {
        getUser: vi.fn().mockResolvedValue({ data: { user: { id: 'test-user-id' } } })
      }
    })
  };
});

describe('Módulo de Integração com Gov.br', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('autenticarViaGovBr', () => {
    it('deve autenticar usuário via Gov.br e registrar integração', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = {
        id: 'integracao-123',
        usuario_id: 'test-user-id',
        token: expect.stringContaining('govbr_token_'),
        data_expiracao: expect.any(String),
        status: 'ativo'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              upsert: () => ({
                select: () => ({
                  single: () => ({ data: mockData, error: null })
                })
              })
            }),
            auth: {
              getUser: () => ({ data: { user: { id: 'test-user-id' } } })
            }
          })
        };
      });

      // Executar função
      const result = await autenticarViaGovBr('auth-code-123', 'https://app.com/callback');

      // Verificar resultado
      expect(result).toEqual(mockData);
      expect(result.token).toContain('govbr_token_');
      expect(result.status).toBe('ativo');
    });

    it('deve lançar erro se usuário não estiver autenticado', async () => {
      // Configurar mock para retornar usuário nulo
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            auth: {
              getUser: () => ({ data: { user: null } })
            })
          })
        };
      });

      // Executar função e verificar erro
      await expect(
        autenticarViaGovBr('auth-code-123', 'https://app.com/callback')
      ).rejects.toThrow('Usuário não autenticado');
    });
  });

  describe('obterPerfilGovBr', () => {
    it('deve obter perfil do usuário no Gov.br', async () => {
      // Configurar mock para retornar integração ativa
      const mockIntegracao = {
        id: 'integracao-123',
        usuario_id: 'test-user-id',
        token: 'govbr_token_123',
        data_expiracao: new Date(Date.now() + 86400000).toISOString(), // Expira em 1 dia
        status: 'ativo'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                eq: () => ({
                  eq: () => ({
                    single: () => ({ data: mockIntegracao, error: null })
                  })
                })
              }),
              update: () => ({
                eq: () => ({ data: null, error: null })
              })
            })
          })
        };
      });

      // Executar função
      const result = await obterPerfilGovBr('test-user-id');

      // Verificar resultado
      expect(result).toHaveProperty('nome');
      expect(result).toHaveProperty('cpf');
      expect(result).toHaveProperty('nivel_autenticacao');
    });

    it('deve lançar erro se integração não for encontrada', async () => {
      // Configurar mock para retornar erro
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                eq: () => ({
                  eq: () => ({
                    single: () => ({ data: null, error: { message: 'Not found' } })
                  })
                })
              })
            })
          })
        };
      });

      // Executar função e verificar erro
      await expect(
        obterPerfilGovBr('test-user-id')
      ).rejects.toThrow('Integração com Gov.br não encontrada ou inativa');
    });

    it('deve lançar erro se token estiver expirado', async () => {
      // Configurar mock para retornar integração com token expirado
      const mockIntegracao = {
        id: 'integracao-123',
        usuario_id: 'test-user-id',
        token: 'govbr_token_123',
        data_expiracao: new Date(Date.now() - 86400000).toISOString(), // Expirou há 1 dia
        status: 'ativo'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                eq: () => ({
                  eq: () => ({
                    single: () => ({ data: mockIntegracao, error: null })
                  })
                })
              })
            })
          })
        };
      });

      // Executar função e verificar erro
      await expect(
        obterPerfilGovBr('test-user-id')
      ).rejects.toThrow('Token Gov.br expirado');
    });
  });

  describe('validarDocumentoViaGovBr', () => {
    it('deve validar documento via Gov.br', async () => {
      // Configurar mock para retornar integração ativa
      const mockIntegracao = {
        id: 'integracao-123',
        cliente_id: 'cliente-123',
        token: 'govbr_token_123',
        data_expiracao: new Date(Date.now() + 86400000).toISOString(), // Expira em 1 dia
        status: 'ativo'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: (table) => {
              if (table === 'integracao_govbr') {
                return {
                  select: () => ({
                    eq: () => ({
                      eq: () => ({
                        single: () => ({ data: mockIntegracao, error: null })
                      })
                    })
                  })
                };
              } else if (table === 'documentos') {
                return {
                  update: () => ({
                    eq: () => ({ data: null, error: null })
                  })
                };
              }
              return {};
            }
          })
        };
      });

      // Executar função
      const result = await validarDocumentoViaGovBr('cliente-123', 'documento-123', 'RG');

      // Verificar resultado
      expect(result).toHaveProperty('documento_id', 'documento-123');
      expect(result).toHaveProperty('tipo_documento', 'RG');
      expect(result).toHaveProperty('validado', true);
      expect(result).toHaveProperty('hash_validacao');
    });
  });

  describe('conectarClienteGovBr', () => {
    it('deve gerar link de autorização e registrar solicitação de integração', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = {
        id: 'integracao-123',
        cliente_id: 'cliente-123',
        usuario_id: 'test-user-id',
        status: 'pendente'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              insert: () => ({
                select: () => ({
                  single: () => ({ data: mockData, error: null })
                })
              })
            }),
            auth: {
              getUser: () => ({ data: { user: { id: 'test-user-id' } } })
            }
          })
        };
      });

      // Executar função
      const result = await conectarClienteGovBr('cliente-123', '12345678900');

      // Verificar resultado
      expect(result).toHaveProperty('link_autorizacao');
      expect(result.link_autorizacao).toContain('sso.acesso.gov.br/authorize');
      expect(result).toHaveProperty('integracao');
      expect(result.integracao).toEqual(mockData);
    });

    it('deve lançar erro se usuário não estiver autenticado', async () => {
      // Configurar mock para retornar usuário nulo
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            auth: {
              getUser: () => ({ data: { user: null } })
            })
          })
        };
      });

      // Executar função e verificar erro
      await expect(
        conectarClienteGovBr('cliente-123', '12345678900')
      ).rejects.toThrow('Usuário não autenticado');
    });
  });
});
