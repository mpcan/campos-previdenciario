import { describe, it, expect, vi, beforeEach } from 'vitest';
import { 
  consultarBeneficioINSS,
  consultarProcessoINSS,
  enviarDocumentosINSS,
  consultarExigenciasINSS,
  responderExigenciaINSS,
  agendarAtendimentoSGA,
  consultarAgendamentosSGA
} from '../src/lib/integracoes/inss-sga';

// Mock do cliente Supabase
vi.mock('@supabase/supabase-js', () => {
  const mockSelect = vi.fn().mockReturnThis();
  const mockEq = vi.fn().mockReturnThis();
  const mockSingle = vi.fn().mockReturnThis();
  const mockInsert = vi.fn().mockReturnThis();
  const mockUpdate = vi.fn().mockReturnThis();
  const mockIn = vi.fn().mockReturnThis();
  const mockOrder = vi.fn().mockReturnThis();
  
  return {
    createClient: () => ({
      from: () => ({
        select: mockSelect,
        insert: mockInsert,
        update: mockUpdate,
        eq: mockEq,
        in: mockIn,
        order: mockOrder,
        single: mockSingle
      })
    })
  };
});

describe('Módulo de Integração com INSS e SGA', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('consultarBeneficioINSS', () => {
    it('deve consultar benefício no INSS e registrar consulta', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = {
        id: 'consulta-123',
        numero_beneficio: '123456789',
        tipo_consulta: 'beneficio',
        resultado: {
          numero_beneficio: '123456789',
          tipo_beneficio: 'Aposentadoria por Tempo de Contribuição',
          status: 'Ativo'
        },
        data_consulta: expect.any(String)
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              insert: () => ({
                select: () => ({
                  single: () => ({ data: mockData, error: null })
                })
              })
            })
          })
        };
      });

      // Executar função
      const result = await consultarBeneficioINSS('123456789');

      // Verificar resultado
      expect(result).toHaveProperty('numero_beneficio', '123456789');
      expect(result).toHaveProperty('tipo_beneficio');
      expect(result).toHaveProperty('status');
      expect(result).toHaveProperty('titular');
    });
  });

  describe('consultarProcessoINSS', () => {
    it('deve consultar processo no INSS e atualizar integração', async () => {
      // Configurar mock para retornar dados simulados
      const mockConsulta = {
        id: 'consulta-123',
        numero_processo: 'INSS123456789',
        tipo_consulta: 'processo',
        resultado: {
          numero_processo: 'INSS123456789',
          tipo_processo: 'Concessão de Benefício',
          status: 'Em Análise'
        },
        data_consulta: expect.any(String)
      };
      
      const mockIntegracao = {
        id: 'integracao-123',
        processo_id: 'processo-123',
        status_beneficio: 'Em Análise',
        dados_adicionais: {
          numero_processo: 'INSS123456789',
          tipo_processo: 'Concessão de Benefício',
          status: 'Em Análise'
        },
        data_atualizacao: expect.any(String)
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: (table) => {
              if (table === 'consultas_inss') {
                return {
                  insert: () => ({
                    select: () => ({
                      single: () => ({ data: mockConsulta, error: null })
                    })
                  })
                };
              } else if (table === 'integracao_inss') {
                return {
                  upsert: () => ({
                    select: () => ({
                      single: () => ({ data: mockIntegracao, error: null })
                    })
                  })
                };
              }
              return {};
            }
          })
        };
      });

      // Executar função
      const result = await consultarProcessoINSS('INSS123456789', 'processo-123');

      // Verificar resultado
      expect(result).toHaveProperty('numero_processo', 'INSS123456789');
      expect(result).toHaveProperty('tipo_processo');
      expect(result).toHaveProperty('status');
      expect(result).toHaveProperty('exigencias');
      expect(result).toHaveProperty('andamentos');
    });
  });

  describe('enviarDocumentosINSS', () => {
    it('deve enviar documentos ao INSS e registrar envio', async () => {
      // Configurar mock para retornar dados simulados
      const mockDocumentos = [
        { id: 'doc-1', nome: 'RG', tipo: 'documento_pessoal' },
        { id: 'doc-2', nome: 'CPF', tipo: 'documento_pessoal' }
      ];
      
      const mockEnvio = {
        id: 'envio-123',
        processo_id: 'processo-123',
        numero_processo: 'INSS123456789',
        documentos_ids: ['doc-1', 'doc-2'],
        protocolo: expect.stringContaining('INSS'),
        resultado: {
          protocolo: expect.stringContaining('INSS'),
          data_envio: expect.any(String),
          documentos_enviados: expect.any(Array),
          status: 'Enviado com Sucesso'
        },
        data_envio: expect.any(String)
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: (table) => {
              if (table === 'documentos') {
                return {
                  select: () => ({
                    in: () => ({ data: mockDocumentos, error: null })
                  }),
                  update: () => ({
                    in: () => ({ data: null, error: null })
                  })
                };
              } else if (table === 'envios_inss') {
                return {
                  insert: () => ({
                    select: () => ({
                      single: () => ({ data: mockEnvio, error: null })
                    })
                  })
                };
              }
              return {};
            }
          })
        };
      });

      // Executar função
      const result = await enviarDocumentosINSS('processo-123', 'INSS123456789', ['doc-1', 'doc-2']);

      // Verificar resultado
      expect(result).toHaveProperty('protocolo');
      expect(result).toHaveProperty('data_envio');
      expect(result).toHaveProperty('documentos_enviados');
      expect(result).toHaveProperty('status', 'Enviado com Sucesso');
    });
  });

  describe('consultarExigenciasINSS', () => {
    it('deve consultar exigências pendentes', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = [
        {
          id: 'integracao-123',
          processo_id: 'processo-123',
          dados_adicionais: {
            exigencias: [
              {
                descricao: 'Apresentar comprovante de residência atualizado',
                data_exigencia: '2025-04-15',
                prazo: '2025-05-15',
                status: 'Pendente'
              }
            ]
          },
          processos: {
            id: 'processo-123',
            numero: 'INSS123456789',
            cliente_id: 'cliente-123',
            tipo: 'Concessão',
            status: 'Em Análise'
          }
        }
      ];
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                eq: () => ({ data: mockData, error: null })
              })
            })
          })
        };
      });

      // Executar função
      const result = await consultarExigenciasINSS('processo-123');

      // Verificar resultado
      expect(result).toHaveLength(1);
      expect(result[0]).toHaveProperty('processo_id', 'processo-123');
      expect(result[0].dados_adicionais).toHaveProperty('exigencias');
      expect(result[0].dados_adicionais.exigencias[0]).toHaveProperty('status', 'Pendente');
    });
  });

  describe('agendarAtendimentoSGA', () => {
    it('deve agendar atendimento no SGA e criar evento na agenda', async () => {
      // Configurar mock para retornar dados simulados
      const mockCliente = {
        id: 'cliente-123',
        nome: 'João Silva',
        cpf: '12345678900',
        telefone: '11999999999',
        email: 'joao@exemplo.com'
      };
      
      const mockAgendamento = {
        id: 'agendamento-123',
        cliente_id: 'cliente-123',
        tipo_servico: 'Perícia Médica',
        data_hora: '2025-05-10T10:00:00Z',
        unidade_atendimento: 'INSS Centro',
        protocolo: expect.stringContaining('SGA'),
        resultado: {
          protocolo: expect.stringContaining('SGA'),
          cliente: {
            nome: 'João Silva',
            cpf: '12345678900'
          },
          servico: 'Perícia Médica',
          unidade: 'INSS Centro',
          data_hora: '2025-05-10T10:00:00Z',
          status: 'Agendado'
        },
        status: 'Agendado'
      };
      
      const mockEvento = {
        id: 'evento-123',
        titulo: 'Atendimento Perícia Médica - João Silva',
        descricao: expect.stringContaining('Protocolo: SGA'),
        data_hora_inicio: '2025-05-10T10:00:00Z',
        data_hora_fim: expect.any(String),
        local: 'INSS Centro',
        cliente_id: 'cliente-123'
      };
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: (table) => {
              if (table === 'clientes') {
                return {
                  select: () => ({
                    eq: () => ({
                      single: () => ({ data: mockCliente, error: null })
                    })
                  })
                };
              } else if (table === 'agendamentos_sga') {
                return {
                  insert: () => ({
                    select: () => ({
                      single: () => ({ data: mockAgendamento, error: null })
                    })
                  })
                };
              } else if (table === 'eventos') {
                return {
                  insert: () => ({
                    select: () => ({
                      single: () => ({ data: mockEvento, error: null })
                    })
                  })
                };
              }
              return {};
            }
          })
        };
      });

      // Executar função
      const result = await agendarAtendimentoSGA(
        'cliente-123',
        'Perícia Médica',
        new Date('2025-05-10T10:00:00Z'),
        'INSS Centro'
      );

      // Verificar resultado
      expect(result).toHaveProperty('agendamento');
      expect(result).toHaveProperty('evento');
      expect(result.agendamento).toHaveProperty('protocolo');
      expect(result.agendamento).toHaveProperty('status', 'Agendado');
      expect(result.evento).toHaveProperty('titulo');
      expect(result.evento).toHaveProperty('data_hora_inicio');
    });
  });

  describe('consultarAgendamentosSGA', () => {
    it('deve consultar agendamentos no SGA', async () => {
      // Configurar mock para retornar dados simulados
      const mockData = [
        {
          id: 'agendamento-123',
          cliente_id: 'cliente-123',
          tipo_servico: 'Perícia Médica',
          data_hora: '2025-05-10T10:00:00Z',
          unidade_atendimento: 'INSS Centro',
          protocolo: 'SGA123456',
          status: 'Agendado',
          clientes: {
            id: 'cliente-123',
            nome: 'João Silva',
            cpf: '12345678900',
            telefone: '11999999999',
            email: 'joao@exemplo.com'
          }
        },
        {
          id: 'agendamento-456',
          cliente_id: 'cliente-123',
          tipo_servico: 'Atendimento Geral',
          data_hora: '2025-05-15T14:00:00Z',
          unidade_atendimento: 'INSS Norte',
          protocolo: 'SGA654321',
          status: 'Agendado',
          clientes: {
            id: 'cliente-123',
            nome: 'João Silva',
            cpf: '12345678900',
            telefone: '11999999999',
            email: 'joao@exemplo.com'
          }
        }
      ];
      
      vi.mock('@supabase/supabase-js', () => {
        return {
          createClient: () => ({
            from: () => ({
              select: () => ({
                order: () => ({
                  eq: () => ({ data: mockData, error: null })
                })
              })
            })
          })
        };
      });

      // Executar função
      const result = await consultarAgendamentosSGA('cliente-123');

      // Verificar resultado
      expect(result).toHaveLength(2);
      expect(result[0]).toHaveProperty('cliente_id', 'cliente-123');
      expect(result[0]).toHaveProperty('tipo_servico');
      expect(result[0]).toHaveProperty('protocolo');
      expect(result[0]).toHaveProperty('status');
      expect(result[0]).toHaveProperty('clientes');
    });
  });
});
