import { createClient } from '@supabase/supabase-js';
import { Database } from '../types';

// Função para consultar benefícios no INSS
export async function consultarBeneficioINSS(numeroBeneficio: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  
  // Simulação de consulta à API do INSS Digital
  // Em produção, faria uma requisição HTTP real para a API do INSS
  const beneficioSimulado = {
    numero_beneficio: numeroBeneficio,
    tipo_beneficio: 'Aposentadoria por Tempo de Contribuição',
    status: 'Ativo',
    data_inicio: '2020-01-15',
    valor_atual: 2500.75,
    titular: {
      nome: 'Nome do Beneficiário',
      cpf: '123.456.789-00'
    }
  };
  
  // Registrar consulta no banco de dados
  const { data, error } = await supabase
    .from('consultas_inss')
    .insert({
      numero_beneficio: numeroBeneficio,
      tipo_consulta: 'beneficio',
      resultado: beneficioSimulado,
      data_consulta: new Date().toISOString()
    })
    .select()
    .single();
  
  if (error) {
    console.error('Erro ao registrar consulta INSS:', error);
    throw error;
  }
  
  return beneficioSimulado;
}

// Função para consultar processos administrativos no INSS
export async function consultarProcessoINSS(numeroProcesso: string, processoId: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  
  // Simulação de consulta à API do INSS Digital
  // Em produção, faria uma requisição HTTP real para a API do INSS
  const processoSimulado = {
    numero_processo: numeroProcesso,
    tipo_processo: 'Concessão de Benefício',
    status: 'Em Análise',
    data_abertura: '2025-03-10',
    ultima_atualizacao: '2025-04-15',
    exigencias: [
      {
        descricao: 'Apresentar comprovante de residência atualizado',
        data_exigencia: '2025-04-15',
        prazo: '2025-05-15',
        status: 'Pendente'
      }
    ],
    andamentos: [
      {
        data: '2025-03-10',
        descricao: 'Processo aberto'
      },
      {
        data: '2025-04-15',
        descricao: 'Análise documental'
      }
    ]
  };
  
  // Registrar consulta no banco de dados
  const { data: consultaData, error: consultaError } = await supabase
    .from('consultas_inss')
    .insert({
      numero_processo: numeroProcesso,
      tipo_consulta: 'processo',
      resultado: processoSimulado,
      data_consulta: new Date().toISOString()
    })
    .select()
    .single();
  
  if (consultaError) {
    console.error('Erro ao registrar consulta INSS:', consultaError);
    throw consultaError;
  }
  
  // Atualizar ou criar registro na tabela de integração
  const { data: integracaoData, error: integracaoError } = await supabase
    .from('integracao_inss')
    .upsert({
      processo_id: processoId,
      status_beneficio: processoSimulado.status,
      dados_adicionais: processoSimulado,
      data_atualizacao: new Date().toISOString()
    })
    .select()
    .single();
  
  if (integracaoError) {
    console.error('Erro ao atualizar integração INSS:', integracaoError);
    throw integracaoError;
  }
  
  return processoSimulado;
}

// Função para enviar documentos ao INSS
export async function enviarDocumentosINSS(
  processoId: string,
  numeroProcesso: string,
  documentosIds: string[]
) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  
  // Buscar informações dos documentos
  const { data: documentos, error: docError } = await supabase
    .from('documentos')
    .select('*')
    .in('id', documentosIds);
  
  if (docError) {
    console.error('Erro ao buscar documentos:', docError);
    throw docError;
  }
  
  // Simulação de envio à API do INSS Digital
  // Em produção, faria uma requisição HTTP real para a API do INSS
  const protocoloSimulado = `INSS${Date.now()}`;
  const resultadoEnvio = {
    protocolo: protocoloSimulado,
    data_envio: new Date().toISOString(),
    documentos_enviados: documentos?.map(doc => ({
      id: doc.id,
      nome: doc.nome,
      tipo: doc.tipo,
      status: 'Enviado'
    })),
    status: 'Enviado com Sucesso'
  };
  
  // Registrar envio no banco de dados
  const { data: envioData, error: envioError } = await supabase
    .from('envios_inss')
    .insert({
      processo_id: processoId,
      numero_processo: numeroProcesso,
      documentos_ids: documentosIds,
      protocolo: protocoloSimulado,
      resultado: resultadoEnvio,
      data_envio: new Date().toISOString()
    })
    .select()
    .single();
  
  if (envioError) {
    console.error('Erro ao registrar envio INSS:', envioError);
    throw envioError;
  }
  
  // Atualizar status dos documentos
  await supabase
    .from('documentos')
    .update({
      enviado_inss: true,
      data_envio_inss: new Date().toISOString(),
      protocolo_inss: protocoloSimulado
    })
    .in('id', documentosIds);
  
  return resultadoEnvio;
}

// Função para consultar exigências pendentes
export async function consultarExigenciasINSS(processoId?: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  
  let query = supabase
    .from('integracao_inss')
    .select(`
      *,
      processos (id, numero, cliente_id, tipo, status)
    `);
  
  if (processoId) {
    query = query.eq('processo_id', processoId);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('Erro ao consultar exigências INSS:', error);
    throw error;
  }
  
  // Filtrar apenas registros com exigências pendentes
  const exigenciasPendentes = data?.filter(item => {
    const dadosAdicionais = item.dados_adicionais as any;
    return dadosAdicionais?.exigencias?.some((e: any) => e.status === 'Pendente');
  });
  
  return exigenciasPendentes;
}

// Função para responder exigência
export async function responderExigenciaINSS(
  processoId: string,
  exigenciaIndex: number,
  documentosIds: string[]
) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  
  // Buscar informações do processo e exigências
  const { data: integracao, error: integracaoError } = await supabase
    .from('integracao_inss')
    .select('*')
    .eq('processo_id', processoId)
    .single();
  
  if (integracaoError) {
    console.error('Erro ao buscar integração INSS:', integracaoError);
    throw integracaoError;
  }
  
  // Buscar informações dos documentos
  const { data: documentos, error: docError } = await supabase
    .from('documentos')
    .select('*')
    .in('id', documentosIds);
  
  if (docError) {
    console.error('Erro ao buscar documentos:', docError);
    throw docError;
  }
  
  // Simulação de envio à API do INSS Digital
  // Em produção, faria uma requisição HTTP real para a API do INSS
  const protocoloSimulado = `INSS-EXIG-${Date.now()}`;
  const resultadoEnvio = {
    protocolo: protocoloSimulado,
    data_envio: new Date().toISOString(),
    documentos_enviados: documentos?.map(doc => ({
      id: doc.id,
      nome: doc.nome,
      tipo: doc.tipo,
      status: 'Enviado'
    })),
    status: 'Exigência Respondida com Sucesso'
  };
  
  // Atualizar dados adicionais para marcar exigência como respondida
  const dadosAdicionais = integracao.dados_adicionais as any;
  if (dadosAdicionais?.exigencias && dadosAdicionais.exigencias[exigenciaIndex]) {
    dadosAdicionais.exigencias[exigenciaIndex].status = 'Respondida';
    dadosAdicionais.exigencias[exigenciaIndex].data_resposta = new Date().toISOString();
    dadosAdicionais.exigencias[exigenciaIndex].protocolo_resposta = protocoloSimulado;
  }
  
  // Atualizar registro na tabela de integração
  const { data: integracaoAtualizada, error: atualizacaoError } = await supabase
    .from('integracao_inss')
    .update({
      dados_adicionais: dadosAdicionais,
      data_atualizacao: new Date().toISOString()
    })
    .eq('id', integracao.id)
    .select()
    .single();
  
  if (atualizacaoError) {
    console.error('Erro ao atualizar integração INSS:', atualizacaoError);
    throw atualizacaoError;
  }
  
  // Registrar resposta no banco de dados
  const { data: respostaData, error: respostaError } = await supabase
    .from('respostas_exigencias_inss')
    .insert({
      processo_id: processoId,
      integracao_id: integracao.id,
      exigencia_index: exigenciaIndex,
      documentos_ids: documentosIds,
      protocolo: protocoloSimulado,
      resultado: resultadoEnvio,
      data_resposta: new Date().toISOString()
    })
    .select()
    .single();
  
  if (respostaError) {
    console.error('Erro ao registrar resposta de exigência INSS:', respostaError);
    throw respostaError;
  }
  
  return resultadoEnvio;
}

// Função para agendar atendimento no SGA
export async function agendarAtendimentoSGA(
  clienteId: string,
  tipoServico: string,
  dataHora: Date,
  unidadeAtendimento: string
) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  
  // Buscar informações do cliente
  const { data: cliente, error: clienteError } = await supabase
    .from('clientes')
    .select('*')
    .eq('id', clienteId)
    .single();
  
  if (clienteError) {
    console.error('Erro ao buscar cliente:', clienteError);
    throw clienteError;
  }
  
  // Simulação de agendamento no SGA
  // Em produção, faria uma requisição HTTP real para a API do SGA
  const protocoloSimulado = `SGA${Date.now()}`;
  const resultadoAgendamento = {
    protocolo: protocoloSimulado,
    cliente: {
      nome: cliente.nome,
      cpf: cliente.cpf
    },
    servico: tipoServico,
    unidade: unidadeAtendimento,
    data_hora: dataHora.toISOString(),
    status: 'Agendado'
  };
  
  // Registrar agendamento no banco de dados
  const { data: agendamentoData, error: agendamentoError } = await supabase
    .from('agendamentos_sga')
    .insert({
      cliente_id: clienteId,
      tipo_servico: tipoServico,
      data_hora: dataHora.toISOString(),
      unidade_atendimento: unidadeAtendimento,
      protocolo: protocoloSimulado,
      resultado: resultadoAgendamento,
      status: 'Agendado'
    })
    .select()
    .single();
  
  if (agendamentoError) {
    console.error('Erro ao registrar agendamento SGA:', agendamentoError);
    throw agendamentoError;
  }
  
  // Criar evento na agenda
  const { data: eventoData, error: eventoError } = await supabase
    .from('eventos')
    .insert({
      titulo: `Atendimento ${tipoServico} - ${cliente.nome}`,
      descricao: `Atendimento agendado no SGA. Protocolo: ${protocoloSimulado}. Unidade: ${unidadeAtendimento}`,
      data_hora_inicio: dataHora.toISOString(),
      data_hora_fim: new Date(dataHora.getTime() + 30 * 60000).toISOString(), // 30 minutos após
      local: unidadeAtendimento,
      cliente_id: clienteId
    })
    .select()
    .single();
  
  if (eventoError) {
    console.error('Erro ao criar evento na agenda:', eventoError);
    throw eventoError;
  }
  
  return {
    agendamento: resultadoAgendamento,
    evento: eventoData
  };
}

// Função para consultar agendamentos no SGA
export async function consultarAgendamentosSGA(clienteId?: string, protocolo?: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  
  let query = supabase
    .from('agendamentos_sga')
    .select(`
      *,
      clientes (id, nome, cpf, telefone, email)
    `)
    .order('data_hora', { ascending: true });
  
  if (clienteId) {
    query = query.eq('cliente_id', clienteId);
  }
  
  if (protocolo) {
    query = query.eq('protocolo', protocolo);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('Erro ao consultar agendamentos SGA:', error);
    throw error;
  }
  
  return data;
}

// Função para cancelar agendamento no SGA
export async function cancelarAgendamentoSGA(agendamentoId: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
  
  // Buscar informações do agendamento
  const { data: agendamento, error: agendamentoError } = await supabase
    .from('agendamentos_sga')
    .select('*')
    .eq('id', agendamentoId)
    .single();
  
  if (agendamentoError) {
    console.error('Erro ao buscar agendamento:', agendamentoError);
    throw agendamentoError;
  }
  
  // Simulação de cancelamento no SGA
  // Em produção, faria uma requisição HTTP real para a API do SGA
  const resultadoCancelamento = {
    protocolo: agendamento.protocolo,
    status: 'Cancelado',
    data_cancelamento: new Date().toISOString()
  };
  
  // Atualizar status do agendamento
  const { data: agendamentoAtualizado, error: atualizacaoError } = await supabase
    .from('agendamentos_sga')
    .update({
      status: 'Cancelado',
      resultado: {
        ...agendamento.resultado,
        status: 'Cancelado',
        data_cancelamento: new Date().toISOString()
      }
    })
    .eq('id', agendamentoId)
    .select()
    .single();
  
  if (atualizacaoError) {
    console.error('Erro ao atualizar agendamento SGA:', atualizacaoError);
    throw atualizacaoError;
  }
  
  return resultadoCancelamento;
}
