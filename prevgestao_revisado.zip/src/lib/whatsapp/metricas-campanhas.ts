import { createClient } from '@supabase/supabase-js';
import { Database } from '../types';

// Função para obter métricas de uma campanha específica
export async function obterMetricasCampanha(campanhaId: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  // Buscar métricas da campanha
  const { data: metricas, error } = await supabase
    .from('metricas_campanhas')
    .select('*')
    .eq('campanha_id', campanhaId)
    .single();

  if (error && error.code !== 'PGRST116') { // PGRST116 = not found
    console.error('Erro ao buscar métricas da campanha:', error);
    throw error;
  }

  // Se não existir métricas, calcular e criar
  if (!metricas) {
    return await calcularECriarMetricas(campanhaId);
  }

  return metricas;
}

// Função para obter métricas de todas as campanhas
export async function obterMetricasTodasCampanhas() {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  const { data: metricas, error } = await supabase
    .from('metricas_campanhas')
    .select(`
      *,
      campanhas (id, nome, data_criacao, data_envio, status)
    `)
    .order('data_atualizacao', { ascending: false });

  if (error) {
    console.error('Erro ao buscar métricas de campanhas:', error);
    throw error;
  }

  return metricas;
}

// Função para calcular e criar métricas para uma campanha
async function calcularECriarMetricas(campanhaId: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  // Buscar dados da campanha
  const { data: campanha, error: campanhaError } = await supabase
    .from('campanhas')
    .select('*')
    .eq('id', campanhaId)
    .single();

  if (campanhaError) {
    console.error('Erro ao buscar dados da campanha:', campanhaError);
    throw campanhaError;
  }

  // Buscar dados de envios
  const { data: envios, error: enviosError } = await supabase
    .from('campanhas_leads')
    .select('*')
    .eq('campanha_id', campanhaId);

  if (enviosError) {
    console.error('Erro ao buscar dados de envios da campanha:', enviosError);
    throw enviosError;
  }

  // Calcular métricas
  const totalEnviadas = envios?.length || 0;
  const totalEntregues = envios?.filter(e => e.status === 'enviado').length || 0;
  const totalLidas = envios?.filter(e => e.data_leitura !== null).length || 0;
  const totalRespondidas = envios?.filter(e => e.data_resposta !== null).length || 0;
  const totalConvertidas = envios?.filter(e => e.convertido === true).length || 0;
  
  // Calcular taxa de conversão
  const taxaConversao = totalEnviadas > 0 ? (totalConvertidas / totalEnviadas) * 100 : 0;

  // Inserir ou atualizar métricas
  const { data: metricas, error: metricasError } = await supabase
    .from('metricas_campanhas')
    .upsert({
      campanha_id: campanhaId,
      total_enviadas: totalEnviadas,
      total_entregues: totalEntregues,
      total_lidas: totalLidas,
      total_respondidas: totalRespondidas,
      taxa_conversao: taxaConversao,
      data_atualizacao: new Date().toISOString()
    })
    .select()
    .single();

  if (metricasError) {
    console.error('Erro ao criar/atualizar métricas da campanha:', metricasError);
    throw metricasError;
  }

  return metricas;
}

// Função para atualizar status de leitura de uma mensagem
export async function atualizarStatusLeitura(campanhaLeadId: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  const { data, error } = await supabase
    .from('campanhas_leads')
    .update({
      data_leitura: new Date().toISOString()
    })
    .eq('id', campanhaLeadId)
    .select()
    .single();

  if (error) {
    console.error('Erro ao atualizar status de leitura:', error);
    throw error;
  }

  // Recalcular métricas da campanha
  await calcularECriarMetricas(data.campanha_id);

  return data;
}

// Função para atualizar status de resposta de uma mensagem
export async function atualizarStatusResposta(campanhaLeadId: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  const { data, error } = await supabase
    .from('campanhas_leads')
    .update({
      data_resposta: new Date().toISOString()
    })
    .eq('id', campanhaLeadId)
    .select()
    .single();

  if (error) {
    console.error('Erro ao atualizar status de resposta:', error);
    throw error;
  }

  // Recalcular métricas da campanha
  await calcularECriarMetricas(data.campanha_id);

  return data;
}

// Função para marcar lead como convertido
export async function marcarLeadComoConvertido(campanhaLeadId: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  const { data, error } = await supabase
    .from('campanhas_leads')
    .update({
      convertido: true,
      data_conversao: new Date().toISOString()
    })
    .eq('id', campanhaLeadId)
    .select()
    .single();

  if (error) {
    console.error('Erro ao marcar lead como convertido:', error);
    throw error;
  }

  // Recalcular métricas da campanha
  await calcularECriarMetricas(data.campanha_id);

  return data;
}

// Função para gerar relatório de conversão por campanha
export async function gerarRelatorioConversaoPorCampanha(
  dataInicio?: Date,
  dataFim?: Date
) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  let query = supabase
    .from('metricas_campanhas')
    .select(`
      *,
      campanhas (id, nome, data_criacao, data_envio, status, mensagem)
    `)
    .order('taxa_conversao', { ascending: false });

  // Aplicar filtros de data se fornecidos
  if (dataInicio || dataFim) {
    query = query.in('campanhas.id', 
      supabase
        .from('campanhas')
        .select('id')
        .gte('data_criacao', dataInicio ? dataInicio.toISOString() : '')
        .lte('data_criacao', dataFim ? dataFim.toISOString() : new Date().toISOString())
    );
  }

  const { data, error } = await query;

  if (error) {
    console.error('Erro ao gerar relatório de conversão por campanha:', error);
    throw error;
  }

  return data;
}

// Função para gerar relatório de horários com melhor taxa de resposta
export async function gerarRelatorioHorariosResposta() {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  // Esta consulta requer SQL personalizado para extrair a hora do dia
  const { data, error } = await supabase.rpc('analisar_horarios_resposta');

  if (error) {
    console.error('Erro ao gerar relatório de horários de resposta:', error);
    throw error;
  }

  return data;
}

// Função para gerar relatório de efetividade por tipo de mensagem
export async function gerarRelatorioEfetividadePorTipoMensagem() {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  // Esta consulta requer análise de conteúdo das mensagens
  // Implementação simplificada - em produção usaria análise de texto mais sofisticada
  const { data: campanhas, error } = await supabase
    .from('campanhas')
    .select(`
      id,
      nome,
      mensagem,
      metricas_campanhas (total_enviadas, total_respondidas, taxa_conversao)
    `);

  if (error) {
    console.error('Erro ao buscar dados para relatório de efetividade:', error);
    throw error;
  }

  // Categorizar mensagens (simplificado)
  const categorias = {
    promocao: [] as any[],
    informativo: [] as any[],
    pergunta: [] as any[],
    outro: [] as any[]
  };

  campanhas?.forEach(campanha => {
    const mensagem = campanha.mensagem?.toLowerCase() || '';
    
    if (mensagem.includes('desconto') || mensagem.includes('promoção') || mensagem.includes('oferta')) {
      categorias.promocao.push(campanha);
    } else if (mensagem.includes('?')) {
      categorias.pergunta.push(campanha);
    } else if (mensagem.includes('informamos') || mensagem.includes('comunicamos')) {
      categorias.informativo.push(campanha);
    } else {
      categorias.outro.push(campanha);
    }
  });

  // Calcular médias por categoria
  const resultado = Object.entries(categorias).map(([categoria, items]) => {
    if (items.length === 0) return { categoria, taxa_resposta: 0, taxa_conversao: 0 };
    
    const taxaRespostaMedia = items.reduce((acc, item) => {
      const metricas = item.metricas_campanhas?.[0];
      if (!metricas || metricas.total_enviadas === 0) return acc;
      return acc + (metricas.total_respondidas / metricas.total_enviadas * 100);
    }, 0) / items.length;
    
    const taxaConversaoMedia = items.reduce((acc, item) => {
      const metricas = item.metricas_campanhas?.[0];
      if (!metricas) return acc;
      return acc + (metricas.taxa_conversao || 0);
    }, 0) / items.length;
    
    return {
      categoria,
      taxa_resposta: taxaRespostaMedia,
      taxa_conversao: taxaConversaoMedia
    };
  });

  return resultado;
}
