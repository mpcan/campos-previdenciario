import { createClient } from '@supabase/supabase-js';
import { Database } from '../types';

// Função para agendar mensagem com base em regras de automação
export async function agendarMensagemAutomatica({
  leadId,
  clienteId,
  conteudo,
  dataHoraAgendada,
  regraAutomacao,
  criadoPor
}: {
  leadId?: string;
  clienteId?: string;
  conteudo: string;
  dataHoraAgendada: Date;
  regraAutomacao?: string;
  criadoPor: string;
}) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  // Verificar se pelo menos um destinatário foi especificado
  if (!leadId && !clienteId) {
    throw new Error('É necessário especificar pelo menos um destinatário (lead ou cliente)');
  }

  const { data, error } = await supabase
    .from('mensagens_agendadas')
    .insert({
      lead_id: leadId,
      cliente_id: clienteId,
      conteudo,
      data_hora_agendada: dataHoraAgendada.toISOString(),
      status: 'pendente',
      regra_automacao: regraAutomacao,
      criado_por: criadoPor
    })
    .select()
    .single();

  if (error) {
    console.error('Erro ao agendar mensagem:', error);
    throw error;
  }

  return data;
}

// Função para obter mensagens agendadas
export async function obterMensagensAgendadas({
  status,
  leadId,
  clienteId,
  dataInicio,
  dataFim
}: {
  status?: string;
  leadId?: string;
  clienteId?: string;
  dataInicio?: Date;
  dataFim?: Date;
}) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  let query = supabase
    .from('mensagens_agendadas')
    .select(`
      *,
      leads (id, nome, telefone, email),
      clientes (id, nome, telefone, email),
      usuarios (id, nome, email)
    `)
    .order('data_hora_agendada', { ascending: true });

  // Aplicar filtros se fornecidos
  if (status) {
    query = query.eq('status', status);
  }

  if (leadId) {
    query = query.eq('lead_id', leadId);
  }

  if (clienteId) {
    query = query.eq('cliente_id', clienteId);
  }

  if (dataInicio) {
    query = query.gte('data_hora_agendada', dataInicio.toISOString());
  }

  if (dataFim) {
    query = query.lte('data_hora_agendada', dataFim.toISOString());
  }

  const { data, error } = await query;

  if (error) {
    console.error('Erro ao obter mensagens agendadas:', error);
    throw error;
  }

  return data;
}

// Função para processar mensagens agendadas que estão prontas para envio
export async function processarMensagensAgendadas() {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  const agora = new Date();

  // Buscar mensagens pendentes que já passaram da data/hora agendada
  const { data: mensagens, error } = await supabase
    .from('mensagens_agendadas')
    .select(`
      *,
      leads (id, nome, telefone, email),
      clientes (id, nome, telefone, email)
    `)
    .eq('status', 'pendente')
    .lte('data_hora_agendada', agora.toISOString());

  if (error) {
    console.error('Erro ao buscar mensagens agendadas para processamento:', error);
    throw error;
  }

  // Processar cada mensagem
  for (const mensagem of mensagens || []) {
    try {
      // Determinar o destinatário
      let telefone = '';
      let nome = '';
      
      if (mensagem.lead_id && mensagem.leads) {
        telefone = mensagem.leads.telefone;
        nome = mensagem.leads.nome;
      } else if (mensagem.cliente_id && mensagem.clientes) {
        telefone = mensagem.clientes.telefone;
        nome = mensagem.clientes.nome;
      }

      if (!telefone) {
        // Atualizar status para erro se não houver telefone
        await supabase
          .from('mensagens_agendadas')
          .update({ status: 'erro' })
          .eq('id', mensagem.id);
        continue;
      }

      // Personalizar a mensagem
      let conteudoPersonalizado = mensagem.conteudo
        .replace('{nome}', nome)
        .replace('{telefone}', telefone);

      // Enviar a mensagem via WhatsApp
      await enviarMensagemWhatsApp({
        telefone,
        mensagem: conteudoPersonalizado,
        leadId: mensagem.lead_id,
        clienteId: mensagem.cliente_id
      });

      // Atualizar status para enviado
      await supabase
        .from('mensagens_agendadas')
        .update({ status: 'enviado' })
        .eq('id', mensagem.id);

    } catch (error) {
      console.error(`Erro ao processar mensagem agendada ${mensagem.id}:`, error);
      
      // Atualizar status para erro
      await supabase
        .from('mensagens_agendadas')
        .update({ status: 'erro' })
        .eq('id', mensagem.id);
    }
  }

  return { processadas: mensagens?.length || 0 };
}

// Função auxiliar para enviar mensagem via WhatsApp
async function enviarMensagemWhatsApp({
  telefone,
  mensagem,
  leadId,
  clienteId
}: {
  telefone: string;
  mensagem: string;
  leadId?: string;
  clienteId?: string;
}) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  // Implementação atual usando o número +555533336517
  // Aqui seria a integração com a API do WhatsApp
  
  // Registrar a mensagem no banco de dados
  const { data, error } = await supabase
    .from('mensagens_whatsapp')
    .insert({
      lead_id: leadId,
      cliente_id: clienteId,
      direcao: 'saida',
      conteudo: mensagem,
      status: 'enviado',
      data_hora: new Date().toISOString()
    })
    .select()
    .single();

  if (error) {
    console.error('Erro ao registrar mensagem de WhatsApp:', error);
    throw error;
  }

  return data;
}

// Função para criar regras de automação
export async function criarRegraAutomacao({
  nome,
  descricao,
  tipo,
  gatilho,
  diasApos,
  diasAntes,
  conteudo,
  ativo,
  criadoPor
}: {
  nome: string;
  descricao: string;
  tipo: 'boas_vindas' | 'lembrete_documentos' | 'aviso_pericia' | 'atualizacao_processo';
  gatilho: 'apos_cadastro' | 'antes_evento' | 'mudanca_status';
  diasApos?: number;
  diasAntes?: number;
  conteudo: string;
  ativo: boolean;
  criadoPor: string;
}) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  const { data, error } = await supabase
    .from('regras_automacao')
    .insert({
      nome,
      descricao,
      tipo,
      gatilho,
      dias_apos: diasApos,
      dias_antes: diasAntes,
      conteudo,
      ativo,
      criado_por: criadoPor
    })
    .select()
    .single();

  if (error) {
    console.error('Erro ao criar regra de automação:', error);
    throw error;
  }

  return data;
}

// Função para aplicar regras de automação em novos leads
export async function aplicarRegrasAutomacaoNovoLead(leadId: string) {
  const supabase = createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );

  // Buscar regras de automação ativas para novos leads
  const { data: regras, error } = await supabase
    .from('regras_automacao')
    .select('*')
    .eq('tipo', 'boas_vindas')
    .eq('gatilho', 'apos_cadastro')
    .eq('ativo', true);

  if (error) {
    console.error('Erro ao buscar regras de automação:', error);
    throw error;
  }

  // Buscar informações do lead
  const { data: lead, error: leadError } = await supabase
    .from('leads')
    .select('*')
    .eq('id', leadId)
    .single();

  if (leadError) {
    console.error('Erro ao buscar informações do lead:', leadError);
    throw leadError;
  }

  // Aplicar cada regra
  for (const regra of regras || []) {
    try {
      // Calcular data de envio com base nos dias após
      const dataEnvio = new Date();
      if (regra.dias_apos) {
        dataEnvio.setDate(dataEnvio.getDate() + regra.dias_apos);
      }

      // Personalizar conteúdo
      let conteudo = regra.conteudo
        .replace('{nome}', lead.nome || '')
        .replace('{telefone}', lead.telefone || '');

      // Agendar mensagem
      await agendarMensagemAutomatica({
        leadId,
        conteudo,
        dataHoraAgendada: dataEnvio,
        regraAutomacao: regra.id,
        criadoPor: regra.criado_por
      });
    } catch (error) {
      console.error(`Erro ao aplicar regra de automação ${regra.id} para lead ${leadId}:`, error);
    }
  }
}
